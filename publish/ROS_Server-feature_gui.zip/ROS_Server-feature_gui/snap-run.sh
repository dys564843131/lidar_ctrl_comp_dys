#!/bin/bash

lidar_source=$(rospack find lidar_frame)

running_nodes=()

file=""

host=192.168.1.9
port=25000

StartFrame=0
frame_rows=40
frame_cols=1250
cloud_fps=10

param_files=()

cmdl_param_name=()
cmdl_param_val=()
cmdl_param_node=()

# Camera Command Line Params #
video_stream_provider=""
fps=""
rviz_setup="aqronos.rviz"


single=""


function AddParam 
{
	case $1 in
		host)
			host="$2"
			;;
		port)
			port="$2"
			;;
		fps)
			fps="$2"
			;;
		StartFrame)
			StartFrame="$2"
			;;
		frame_rows)
			frame_rows="$2"
			cmdl_param_name+=("$1")
			cmdl_param_val+=("$2")
			;;
		frame_cols)
			frame_cols="$2"
			cmdl_param_name+=("$1")
			cmdl_param_val+=("$2")
			;;
		cloud_fps)
			cloud_fps="$2"
			cmdl_param_name+=("$1")
			cmdl_param_val+=("$2")
			;;
		*)	
			cmdl_param_name+=("$1")
			cmdl_param_val+=("$2")
			;;
	esac
}


function GetNodeName 
{
	# Get cfg Files
	cfg_files=($(find "$lidar_source/cfg" -name "*.cfg"))
	for (( k=0; k<${#cfg_files[@]}; k++ ));
	do
		if grep -R "${cfg_files[$k]}" -e "$1" &> /dev/null 
		then 
			temp=""
			if [[ -z "$single" ]]
			then
				temp=${cfg_files[$k]##*/}
			else
				temp="/aqronos/"${cfg_files[$k]##*/}
			fi
			temp="${temp%%.cfg}"
			cmdl_param_node+=("$temp")
		fi
	done
}

# Parse Command Line #
while [[ $# -gt 0 ]]
do
	key="$1"

	case $key in
	    *:=*) # Command Line Argument
			AddParam "${key%%:=*}" "${key##*:=}"
		    shift # past value
		    ;;
		*=*) # Command Line Argument
			AddParam "${key%%=*}" "${key##*=}"
		    shift # past value
		    ;;
		*.bin|*.txt)
			# Check if file
			file="$key"
			[[ ! -e "$file" ]] && echo "File $file Not Found"
			name="${file%%.bin}"
			[[ -z "$name" ]] && name="${file%%.txt}"
			name="${name##*/}"
			param_files+=($(find "$lidar_source"/params -name "*$name*.yaml"))
			# Check .ros dir 
			param_files+=($(find ~/.ros -name "*$name*.yaml"))
			shift
			;;
		*.mov|*.mp4|*.webm)
			[[ -e "$key" ]] && video_stream_provider="$key"
			rviz_setup="image.rviz"
			launch_camera="true"
			shift
			;;
		stream)
			rviz_setup="image.rviz"
			launch_camera="true"
			shift
			;;
		--single)
			single="true"
			shift
			;;
		*)
			echo "Uknown Option: " "$key"
			shift
			;;
	esac
done
# GetNodeName "${cmdl_param_name[0]}"
# declare -p cmdl_param_name
# declare -p cmdl_param_val
# declare -p cmdl_param_node
# exit

[[ -e "$file" ]] && host=127.0.0.1 && port=12345


# Launch Main Node
#echo "roslaunch launch/udp.launch &"
#running_nodes+=("$!")
# declare -p rviz_setup
if [[ -z "$single" ]]
then
	roslaunch lidar_frame multi_node.launch host:="$host" port:="$port" rviz_setup:="$rviz_setup" &
else
	roslaunch lidar_frame udp.launch host:="$host" port:="$port" rviz_setup:="$rviz_setup" &
fi
sleep 2 # Give time to launch

# Launch Camera Node
if [[ -n "$launch_camera" ]]
then
	camera_command="roslaunch video_stream_opencv camera.launch"
	[[ -n "$fps" ]] && echo "Camera fps: $fps" && camera_command+=" fps:=$fps"
	[[ -n "$video_stream_provider" ]] && echo "Playing Video: $video_stream_provider" && camera_command+=" video_stream_provider:=$video_stream_provider"
	echo "$camera_command" &
	$camera_commands &
	running_nodes+=("$!")
fi

# Load File Params
for (( i=0; i<${#param_files[@]}; i++ ));
do
	echo "Setting Params from:   ${param_files[$i]}" 
	# Assign correct node for each parameters 
	if [[ -z "$single" ]]
	then
		node_assign=""
	else
		node_assign="/aqronos"
	fi
	grep -R "${param_files[$i]}" -e "y_angle0" &> /dev/null && node_assign+="/pointcloud"
	grep -R "${param_files[$i]}" -e "median_window_size" &> /dev/null && node_assign+="/filter2d"
	grep -R "${param_files[$i]}" -e "PCLMeanK" &> /dev/null && node_assign+="/pcl_filter"
	grep -R "${param_files[$i]}" -e "frame_rows" &> /dev/null && node_assign+="/udp_frame"
	rosrun dynamic_reconfigure dynparam load "${node_assign}" "${param_files[$i]}" -t 1
done


# Set Command Line Params
for (( i=0; i<${#cmdl_param_name[@]}; i++ ));
do
	echo "${cmdl_param_name[$i]}: ${cmdl_param_val[$i]}"
	cmdl_param_node=()

	GetNodeName "${cmdl_param_name[$i]}"
	for (( j=0; j<${#cmdl_param_node[@]}; j++ ));
	do
		echo rosrun dynamic_reconfigure dynparam set "${cmdl_param_node[$j]}" "${cmdl_param_name[$i]}" "${cmdl_param_val[$i]}" 
		rosrun dynamic_reconfigure dynparam set "${cmdl_param_node[$j]}" "${cmdl_param_name[$i]}" "${cmdl_param_val[$i]}" &
		#rosrun dynamic_reconfigure dynparam set "${cmdl_param_node[$j]}" "${cmdl_param_name[$i]}" "${cmdl_param_val[$i]}"
	done
done



if [[ "$file" == *.bin ]]
then
	#rosrun lidar_frame server _file:="$file" &> /dev/null &
	rosrun lidar_frame server _host:="$host" _port:="$port" _file:="$file" _frame_rows:="$frame_rows" _frame_cols:="$frame_cols" _cloud_fps:="$cloud_fps" _start_frame:="$StartFrame"
	#rosrun lidar_frame server _host:="$host" _port:="$port" _file:="$file" _cloud_fps:="$cloud_fps" _start_frame:="$StartFrame"
	running_nodes+=("$!")
	sleep 1
elif [[ "$file" == *.txt ]]
then
	sleep 4
	while IFS='' read -r line || [[ -n "$line" ]]; do
	    b=($(echo "$line"))
	    #[[ "${#b[@]}" -ne 1204 ]] && break
	    s=""
	    for i in "${b[@]}"
	    do
		    s+=\\x"$i"
		    #s+="$i"
		    #echo -n -e '\x'"$i"
	    done
	    echo -e -n  "$s" | nc -u -w0 "$host" "$port"
	    #echo -n -e "$s"  >/dev/udp/"$host"/"$port"
	    sleep 0.001
	    #| nc  -q 1 -u "$host" "$port"
	#    echo "Text read from file: $line"
	    # sleep 0.1
	done < "$file" # | socat -b1204  - udp4:"$host":"$port" #nc -u "$host" "$port"
else
	echo "Press [CTRL+C] to stop.."
	while true
	do
		sleep 1
	done
fi