# ROS Server

ROS package for receiving and displaying Aqronos LiDAR frames received over Ethernet.

## Installation

Installing dependent packages:
```bash
sudo apt install libboost-all-dev git net-tools
```

Cloning the library:
```bash
git clone https://github.com/AQChronos/ROS_Server.git
```

Building the ROS package
```bash
cd ROS_Server/src
rm CMakeLists.txt
catkin_init_workspace # Must already have ROS installed
cd ..
catkin_make  
```

## Updating
To update from the bash repository run:
```bash
git pull 
```
from the source directory.  
and then compile the changes to the code by running:
```bash
catkin_make
```

### Create a static IP Address
The Ethernet interface name should be something like *enp30s0* or *enp0s31f6* and is found with:
```bash
ls /sys/class/net/
```
To set the static ip address of the ethernet interface *enp30s0* to 192.168.1.9, run:
```bash
sudo ifconfig enp30s0 192.168.1.9
```

## Usage
The primary usage is to set the static IP and then run:
```bash
./run.sh host:=192.168.1.9 port:=25000
```
from the ROS_Server directory.  This launches a vizualization node and listens on 192.168.1.9:25000 for udp packets.

To read data from a file. Download and then specify the file name.  For example to vizualize data from "p_driving2.bin", run:
```bash
./run.sh "p_driving2.bin"
```
Note: the quotation marks around the file name are required.  
This will run the vizualization node and display data from the file "zack running.bin" with pre-set parameters for x_delay, y_delay and more. See **Adjustable Parameters** section for more details.  

Other files with pre-set parameters include:
- changan_street_x_0.872_y_0.264.bin
- p_driving2.bin


See run.sh for more detail on default parameters.  

## GUI

The gui contains parameters that can be configured during run time.  
### Setup
To access select the **rqt** window, then select Plugins -> Configuration -> Dynamic Reconfigure.
### Usage
Select the *aqronos* dropdown then select the *node* to modify. It will give a list of parameters
### Saving Parameters
After modifying Parameters you can save these by choosing the save icon in the top left corner of the parameter list.  Parameters must be saved with extention *.yaml* and contain the file name (minus the *.bin*) with which they are associated. Files can be saved in the \~/.ros directory or the ROS_Server/src/lidar_frame/params directory.  Examples are located in the ROS_Server/src/lidar_frame/params directory.  Each *node* must have a separatly saved parameter file.

### Loading Parameters
Parameters are searched by looking for any .yaml in the .ros or ROS_Server/src/lidar_frame/params with name containing the matching file name. 
### Save/Loading Example
You can select *aqronos* -> *pointcloud* from the dropdown, modify the y_angle and save it as test_123.yaml (will save in .ros directory by default).  To load these parameters on the next runs use:
```bash
./run.sh host:=127.0.0.1 test
```
### Default Values
Default values are found in the ROS_Server/src/lidar_frame/cfg/\*.cfg files.  The default value is the 5th parameter from the left or 3rd parameter from the right.  The Min and then Max settings are the last two parameters.


## Command Line Parameters
All GUI parameters can be set from the command line with:
```bash
./run.sh $param:=$val
```
Additional parameters that can be set from the command line are given here:

| Name        | Type           | Default Value  | Description  |
| ------------- |:-------------:| :-----:| :-----:|
| host      | string | 192.168.1.9 |
| port      | int      |   25000 |

## License
TODO

