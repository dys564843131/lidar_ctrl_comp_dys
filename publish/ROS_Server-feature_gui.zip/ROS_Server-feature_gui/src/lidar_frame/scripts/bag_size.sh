#!/bin/bash

sum=0
for bag in ./*.bag
do
	((sum+=$(stat -c'%s' "$bag")))
done
echo $sum
exit 0
