#ifndef PACKET_SEND_HPP 
#define PACKET_SEND_HPP 

#include <chrono>
#include <thread>
#include <mutex>
#include <queue>
#include <atomic>
#include <condition_variable>
#include <boost/asio.hpp>

#define MAX_QUEUE_SIZE 100000

//#define MAX_FRAME_COUNTER 10000000 // Just set large enough to cover any frame and keep frame_counter from overflowing

/* Packet Info */
#define HEADER_BYTES 4
#define POINTS_PER_PACKET 300
#define POINT_BYTES 4

using boost::asio::ip::udp;

class PacketSend
{
	public:
		PacketSend(std::string host="127.0.0.1", short port =25000, int frame_points=50000, int cloud_fps=10, double st=300)
		: sleep_time(st)
		, q(), m(), c(), cont(true)
		, socket_(io_service)
		, sender_endpoint_(boost::asio::ip::address::from_string(host), port)
		, t(&PacketSend::WorkerThread, this)
		, frame_points(frame_points)
		, cloud_fps(cloud_fps)
		{
			/* (10^6 us / s) X ( s / Frame ) X ( Frame / Points ) X ( Points / Packet ) 
			 * ==> (us / Packet) aka sleep_time between each packet
			 * OLD, LEGACY
			 */
			sleep_time = 1000000 * POINTS_PER_PACKET / ((double) frame_points * cloud_fps);
			sleep_time = std::min(250.0, sleep_time - 100); 
			// Send as fast as possible.  Limit display rate with ROS Timer callback
			sleep_time = 200.0;
			
			socket_.open(udp::v4());
		}

		void SetSleepTime(double st)
		{
			sleep_time = st;
		}

		void SetPort(short p)
		{
			sender_endpoint_.port(p);
		}

		void SetAddr(std::string h)
		{
			sender_endpoint_.address(boost::asio::ip::address::from_string(h));
		}

		int GetSleepTime()
		{
			return sleep_time;
		}

		int GetPort()
		{
			return sender_endpoint_.port();
		}

		void Reset()
		{
			clear();
			frame_counter = 0;
		}

		void clear()
		{
			std::lock_guard<std::mutex> lock(m);
			std::queue<std::pair<float, float>> empty;
			std::swap( q, empty );
		}

		// boost::asio::ip::basic_endpoint<InternetProtocol> GetAddr()
		// {
		// 	return sender_endpoint_.address();
		// }

		~PacketSend()
		{
			// std::cout << "Killing threads" << std::endl;
			cont.store(false);
			c.notify_all();
			t.join();
		}

		void SendUDP(float data[], int data_length, int vel_offset)
		{
			pt_frame = vel_offset;
			// std::cout << "QUEUE SIZE:  " << q.size() << std::endl;
			/* Delay main thread if too many points are queued up */
			while(q.size() > MAX_QUEUE_SIZE)
			{
				std::this_thread::sleep_for(std::chrono::microseconds(800));
			}

			std::lock_guard<std::mutex> lock(m);
			for(int i=0; i<floor(data_length / 2.0); ++i)
			{
				if((i + vel_offset) > data_length)
					break;
				q.push( std::make_pair(data[i], data[i+vel_offset]) );
			}			
		}
	
	private:
		void WorkerThread()
		{
			while( cont.load() )
			{
				/* Lock queue */
				std::unique_lock<std::mutex> lock(m);	
				if( q.size() >= POINTS_PER_PACKET )
				{
					/* Data For UDP Packet */
					int packet_bytes = HEADER_BYTES + (POINT_BYTES * POINTS_PER_PACKET);
					char _data[packet_bytes];

			        /* Set header to frame counter */
					_data[0] = static_cast<char> (frame_counter) & 0x000000FF;
					_data[1] = static_cast<char> (frame_counter >> 8) & 0x000000FF;
					_data[2] = static_cast<char> (frame_counter >> 16) & 0x000000FF;
					_data[3] = static_cast<char> (frame_counter >> 24) & 0x000000FF;

			        /* Fill _data with points */
			        int byte;
			        for(byte = HEADER_BYTES; byte < packet_bytes; byte+=POINT_BYTES, frame_counter++)
			        {
			            /* Ignore triggers and avg intensity */
			            _data[byte] = 0;
			            // if(frame_counter % 50000 == (50000 - 1))
			            // {
			            // 	_data[byte] |= 0x1; // trig I
			            // }
			            // if( (frame_counter) % 7500 == 0)
			            // {
			            // 	_data[byte] |= 0x4; // trig A
			            // }

			            /* For sending Trig B */
			            // if(frame_counter % 50000 == 0)
			            // {
			            // 	_data[byte] |= 0x02;
			            // }

			            /* Convert radius and velocity from input data into uint16_t */
			            uint16_t radius = roundf(q.front().first);
			            //std::cout << "Rad diff: " << abs(radius - q.front().first) << std::endl;
			            uint16_t velocity = roundf(q.front().second);
			            q.pop();

			            /* Break apart radius and velocity into bytes.  Add to packet _data array. */
			            _data[byte + 1] = velocity & 0x0FF;
			            _data[byte + 2] = 0;
			            _data[byte + 2] |= (velocity & 0x0F00) >> 8;
			            _data[byte + 2] |= (radius & 0x0F) << 4;
			            _data[byte + 3] = (radius & 0x0FF0) >> 4;
			        }

			   //      if(frame_counter <= POINTS_PER_PACKET)
			   //      {
			   //      	std::cout << std::endl;
			   //      	std::cout.setf( std::ios_base::hex, std::ios::basefield );
						// for ( int i = 0; i < packet_bytes; ++ i ) {
						// 	std::cout << std::setw(2) << std::setfill('0') << static_cast<unsigned>( static_cast<unsigned char>( _data[i] ) );
						// 	std::cout << " ";
						// }
						// std::cout.setf( std::ios_base::dec, std::ios::basefield );
						// std::cout << std::endl << std::endl;
			   //      }

			        /* Send _data */
			        // std::cout << "Packet Sent" << std::endl;
			        //if(rand() % 1000 != 0)
			        //if(frame_counter < 978300 || frame_counter > 1007700)
			        {
			        	boost::system::error_code err;
			            socket_.send_to(boost::asio::buffer(_data, byte), sender_endpoint_, 0, err);
			        }
			        // frame_counter += POINTS_PER_PACKET;
			        //frame_counter %= MAX_FRAME_COUNTER;
			        
				}

				/* Unlock queue and wait before sending next packet */
				if(pt_frame == 24000)
					c.wait_for(lock, std::chrono::microseconds(400)); 
				
				c.wait_for(lock, std::chrono::microseconds((int) (sleep_time)));
			}
		}

		/* Queue pair of radius and velocity */
		std::queue<std::pair<float, float>> q;
		uint32_t frame_counter = 0;

		/* Thread Vars */
		mutable std::mutex m;
		std::condition_variable c;
		std::atomic<bool> cont;

		/* UDP Send info */
		boost::asio::io_service io_service;
		udp::endpoint sender_endpoint_;
		udp::socket socket_;

		/* Thread to send upd packets */
		std::thread t;

		int pt_frame;
		int frame_points;
		int cloud_fps;
		double sleep_time;
};

#endif // PACKET_SEND_HPP