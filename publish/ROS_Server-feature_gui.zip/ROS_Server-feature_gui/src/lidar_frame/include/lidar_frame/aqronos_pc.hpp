/*	aqronos_pc.hpp
 * 
 * Bundle together some fields for a filtering queue
 * Along with some predefiend filter functions
 * And ROS publishers
 *
 * maintainer: Nathan Corral (nathan@aqchronos.com)
*/

#ifndef AQRONOS_PC_INCLUDE_HPP 
#define AQRONOS_PC_INCLUDE_HPP

#include "lidar_frame/aqronos_point.hpp"
#include "lidar_frame/point_bins.hpp"

/* Ros Includes */
#include "ros/ros.h"
#include <sensor_msgs/PointCloud2.h>
#include "std_msgs/Header.h"

/* PCL Includes */
#include <pcl_ros/point_cloud.h>
#include <pcl/filters/radius_outlier_removal.h>
#include <pcl/filters/statistical_outlier_removal.h>
#include <pcl/filters/conditional_removal.h>
#include <pcl/filters/extract_indices.h>
#include <pcl/filters/median_filter.h>
#include <pcl/filters/fast_bilateral.h>
#include <pcl/point_types.h>
#include <pcl/keypoints/sift_keypoint.h>
#include <pcl/features/normal_3d.h>
#include <pcl/ModelCoefficients.h>
#include <pcl/filters/extract_indices.h>
#include <pcl/kdtree/kdtree.h>
#include <pcl/segmentation/extract_clusters.h>
#include <pcl/sample_consensus/method_types.h>
#include <pcl/sample_consensus/model_types.h>
#include <pcl/segmentation/sac_segmentation.h>


// #include <pcl/visualization/cloud_viewer.h>
// #include <pcl/common/common_headers.h>
// #include <pcl/io/pcd_io.h>
// #include <pcl/console/parse.h>



#include <vector>

/* OpenCV Includes */
#include "opencv2/imgproc/imgproc.hpp"
#include "opencv2/highgui/highgui.hpp"

/* Remove any points with less than VEL_THRESH_PERC percent of max velocity */
#define VEL_THRESH_PERC 30.0
/* Remove the outside VEL_PERC_FOCUS percent of frame for velocity */
#define VEL_PERC_FOCUS 70.0
#define VEL_CLUSTER_POINTS 40

/* Max Number of moving points before giving up on trying to filter */
#define MAX_VEL_POINTS 15000

/* Draw Bounding Box Points */
//#define POINTS_PER_DIST 0.05

class AqronosPointCloud
{
	public:
		AqronosPointCloud(ros::NodeHandle *n, pcl::PointCloud<AqronosPoint>::Ptr pc_in);
		void Organize(int height, int width);

		void NewGroundFilter( double max_theta, pcl::ModelCoefficients::Ptr coefficients, bool FindCoefficients = false );
		int FilterGround(double bin_size, double theta_thresh, int bin_thresh);

		void RemoveNaN();

		void FilterTheta(const double theta, const bool KeepOrganized = false);

		int GetGroundCoeff(pcl::ModelCoefficients::Ptr coefficients, const double dist_thresh = 0.15, const int method = pcl::SAC_MSAC);

		int GroundFilter(const pcl::ModelCoefficients::Ptr coefficients, const double dist_thresh = 0.15, const bool ColorGround = true);

		bool Filter();

		void ColorVel(const double max_dist, const int min_points);

		/* Some vector functions we mimic */
		/* TODO: Bounds Checking */
		void push_back(const AqronosPoint &p);
		AqronosPoint at(int idx);
		size_t size();


		// void BuildRawMsg(std::string frame_id);
		// void BuildFiltMsg(std::string frame_id);
		void BuildMsg(std::string frame_id);

		/* Length: Positive x from point */
		/* Width: Positive y from point */
		/* Height: Positive z */
		void DrawBoundingBox(pcl::PointXYZ orig, double length, double width, double height);


		/* ROS Data */
		std_msgs::Header header;

		pcl::PointCloud<AqronosPoint>::Ptr _data;
		/* Bounding Box Points for vizualization */
		pcl::PointCloud<AqronosPoint>::Ptr bounding_box; 
		pcl::PointCloud< pcl::PointWithScale >::Ptr keypoints;

		/* Point Cloud Data For Publishing */
		// sensor_msgs::PointCloud2 pc_msg_raw;
		// sensor_msgs::PointCloud2 pc_msg_filt;
		sensor_msgs::PointCloud2 msg;
		sensor_msgs::PointCloud2 box_msg;
		sensor_msgs::PointCloud2 keypoint_msg;

		/* Filtering Internal Operations */
		void PCLRadOultiers(const pcl::PointCloud< AqronosPoint >::Ptr &in, 
						pcl::PointCloud< AqronosPoint >::Ptr &out,
						const int filt_setMinNeighborsInRadius, const double filt_setRadiusSearch);

		void PCLStatOultiers(const pcl::PointCloud< AqronosPoint >::Ptr &in, 
						pcl::PointCloud< AqronosPoint >::Ptr &out,
						const int MeanK, const double StddevMulThresh);

		void PCLMedian(const pcl::PointCloud< AqronosPoint >::Ptr &in, 
						pcl::PointCloud< AqronosPoint >::Ptr &out,
						const int WindowSize);

		void PointsNormal(const pcl::PointCloud< AqronosPoint >::Ptr &in, 
						pcl::PointCloud< pcl::PointNormal >::Ptr &out);

		void PointsSIFT(const pcl::PointCloud< AqronosPoint >::Ptr &in, 
						pcl::PointCloud< pcl::PointWithScale >::Ptr &out);

		// void FilterVelocity(const pcl::PointCloud< AqronosPoint >::Ptr &in, 
		// 				pcl::PointCloud< AqronosPoint >::Ptr &out, int width);

		void FilterRadius(int height, int width);

		void FilterVelWithGround(const double max_dist, const int min_points, const double MinVel, const double MaxVel, const double vel_perc_focus, const double cur_x_delay, const int width);
		int FilterVel(const double max_dist, const int min_points, const double MinVel, const double MaxVel, const double vel_perc_focus, const double cur_x_delay, const int width);
		int FilterVel(const double max_dist, const int min_points, const double vel_perc_focus, const double cur_x_delay, const int width);
		void FilterVel_OLD(const double MinVel, const double MaxVel, const double vel_perc_focus, const double cur_x_delay, const int width);

		int interp_height, interp_width;
		void Interpolate(int height, int width, double thresh);

		void GetKeypoints();

		void Cluster(double cluster_dist = 1.0);

		void VelColor();
		void MaxMinVel(double & ma, double & mi);


		/* Median Filter for recieved frame */
		// void MedianFilter(const std::vector<uint16_t> &in, std::vector<uint16_t> &out);

		//pcl::PointCloud<AqronosPoint>::Ptr raw_data;
		//pcl::PointCloud<AqronosPoint>::Ptr filtered;
		std::vector< Bin > vel_bins_init;

		private:

		// void MergeBins(std::vector<std::vector<int>> &in_idxs, std::vector< pcl::PointXYZ > &centroids, float min_dist, std::vector<std::vector<int>> &out_idxs);

		std::vector<uint8_t> avg_int;
		std::vector<double> vel;
		std::vector<double> rad;
		double vel_avg = 0;
		double ground_vel_max = -1000;
		double ground_vel_min = 1000;
		double ground_vel_avg = 0.0;

		ros::NodeHandle * n;

		int points_added = 0;
};


#endif // AQRONOS_PC_INCLUDE_HPP