#ifndef RINGLIST_HPP_INCLUDED 
#define RINGLIST_HPP_INCLUDED 

#include <pcl/point_types.h>
#include <visualization_msgs/MarkerArray.h>
//#include <geometry_msgs/Point.h>

#include <cmath>
#include <vector>

#include "lidar_frame/ring.hpp"


class RingList
{
public:
	RingList( ros::NodeHandle * n, geometry_msgs::Point center, double ring_dist, double offset ) :
	n(n),
	center(center),
	ring_dist(ring_dist),
	offset(offset)
 	{
 		marker_pub = n->advertise<visualization_msgs::MarkerArray>("distance_rings", 1);
 		// 
 		// ring_scale = 3.0;
 		// scale_pwr = 1.0;
 		BuildRingList();
 		Update();
 	}

 	void AddTimer()
 	{
 		timer = n->createTimer(ros::Duration(1), &RingList::timerCallback, this);
 	}

 	~RingList()
 	{
 		/* Publish empty ring marker array */
 		list.markers.clear();
 		marker_pub.publish( list );
 	}

 	void SetCenter(geometry_msgs::Point new_center)
 	{
 		center = new_center;
 		// std::cout << "Cnter: " << center.x << std::endl;
 		BuildRingList();
 		Update();
 	}



 	void BuildRingList()
 	{
 		ring_list.clear();

 		for(int i=1; i<20; ++i)
 		{
 			if(i <= 10)
 			{
 				ring_list.push_back(Ring(i*5, center));
 			}
 			else
 			{
 				//ring_list.push_back(Ring(((i-5)*10 + 50, center)));
 				//std::cout << "r: " << (i-5)*10 << std::endl;
 				ring_list.push_back(Ring((i-5)*10, center));
 			}
 		}
 		return;

 		double scale;
 		if(ring_dist > 70)
 		{
 			scale = 0.2;
 		}
 		else if(ring_dist >= 10)
 		{
 			scale = 0.1;
 		}
 		else
 		{
 			scale = 0.05;
 		}
 		scale = 1;
 		double power = 1;
 		double ring_scale = 1;


 		double num_rings = pow((ring_dist / ring_scale), 1.0/power);
 		// std::cout <<"Num Rings:  " << num_rings/scale << std::endl;
 		for(double i=offset; i<=(num_rings); i+=scale)
		{
			// std::cout << "i  " << i << std::endl;
			// std::cout << "Ring Radius:" << (pow(i,power) * ring_scale + offset) << std::endl;
			ring_list.push_back( Ring(pow(i,power) * ring_scale + offset, center) );
		}
 	}

 	void timerCallback(const ros::TimerEvent&)
 	{
 		BuildRingList();
 		Update();
 	}

 	void Update()
 	{
 		list.markers.clear();
 		int num_rings = 0;
 		for(auto ring : ring_list)
 		{
 			num_rings++;
			list.markers.push_back(ring.circle);
			list.markers.push_back(ring.text);
		}
		// std::cout << "Publishing Ring List with " << num_rings << std::endl;
		marker_pub.publish( list );
 	}

 	visualization_msgs::MarkerArray list;

private:
	geometry_msgs::Point center;
	double ring_dist;
	double offset;
	// double num_rings;
	// double ring_scale;
	// double scale_pwr;
	std::vector<Ring> ring_list;

	ros::NodeHandle * n;
	ros::Publisher marker_pub;
	ros::Timer timer;
};

#endif // RINGLIST_HPP_INCLUDED
