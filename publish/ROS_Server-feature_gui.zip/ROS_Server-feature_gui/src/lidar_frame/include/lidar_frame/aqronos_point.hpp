#ifndef AQRONOS_POINT_INCLUDE 
#define AQRONOS_POINT_INCLUDE

#define PCL_NO_PRECOMPILE

#include <math.h>

#include <pcl/point_types.h>
#include <pcl/impl/point_types.hpp>

#include <pcl/point_cloud.h>

#include <pcl/cloud_iterator.h>
#include <pcl/impl/cloud_iterator.hpp>

#include <pcl/impl/instantiate.hpp>

#include <pcl-1.8/pcl/pcl_base.h>
#include <pcl-1.8/pcl/impl/pcl_base.hpp>

/* Requrired filters and implmentations */
#include <pcl/filters/radius_outlier_removal.h>
#include <pcl/filters/statistical_outlier_removal.h>
#include <pcl/filters/conditional_removal.h>

#include <pcl/filters/impl/radius_outlier_removal.hpp>
#include <pcl/filters/impl/statistical_outlier_removal.hpp>
#include <pcl/filters/impl/conditional_removal.hpp>
#include <pcl/filters/impl/extract_indices.hpp>

// #include <pcl-1.8/pcl/search/impl/search.hpp>
// #include <pcl-1.8/pcl/search/impl/kdtree.hpp>
// #include <pcl-1.8/pcl/search/impl/organized.hpp>
// #include <pcl-1.8/pcl/search/impl/flann_search.hpp>
// #include <pcl-1.8/pcl/kdtree/impl/kdtree_flann.hpp>

/* Image Viewer Stuff */
// #include <pcl-1.8/pcl/visualization/histogram_visualizer.h>
// #include <pcl-1.8/pcl/visualization/image_viewer.h>
// #include <pcl-1.8/pcl/visualization/pcl_plotter.h>
// #include <pcl/visualization/pcl_visualizer.h>
// #include <pcl-1.8/pcl/visualization/point_cloud_color_handlers.h>
// #include <pcl-1.8/pcl/visualization/point_cloud_geometry_handlers.h>
// #include <pcl-1.8/pcl/visualization/point_cloud_handlers.h>
// #include <pcl-1.8/pcl/visualization/registration_visualizer.h>

// #include <pcl-1.8/pcl/visualization/impl/histogram_visualizer.hpp>
// #include <pcl-1.8/pcl/visualization/impl/image_viewer.hpp>
// #include <pcl-1.8/pcl/visualization/impl/pcl_plotter.hpp>
// #include <pcl-1.8/pcl/visualization/impl/pcl_visualizer.hpp>
// #include <pcl-1.8/pcl/visualization/impl/point_cloud_color_handlers.hpp>
// #include <pcl-1.8/pcl/visualization/impl/point_cloud_geometry_handlers.hpp>
// #include <pcl-1.8/pcl/visualization/impl/point_cloud_handlers.hpp>
// // #include <pcl-1.8/pcl/visualization/impl/registration_visualizer.hpp>

struct _AqronosPoint
{
	PCL_ADD_POINT4D;
	PCL_ADD_RGB;
	uint8_t avg_int;
	double vel;
	double radius;
	float theta;
	float phi;
	int w;	// Height and width in frame
	int h; 
	uint8_t point_moving;
	uint8_t point_in_vel_window;
	double v0;

	inline _AqronosPoint()
	{
		this->x = 0.0f; this->y = 0.0f; this->z = 0.0f;
		this->r = 255; this->g = 255; this->b = 255;
		this->point_moving = false;
		this->point_in_vel_window = false;
		this->v0 = 0;
	}

	inline _AqronosPoint(const _AqronosPoint & a)
	{
		this->x = a.x; this->y = a.y; this->z = a.z;
		this->r = a.r; this->g = a.g; this->b = a.b;
		this->avg_int = a.avg_int;
		this->vel = a.vel;
		this->radius = a.radius;
		this->theta = a.theta;
		this->phi = a.phi;
		this->w = a.w;
		this->h = a.h;
		this->point_moving = a.point_moving;
		this->point_in_vel_window = a.point_in_vel_window;
		this->v0 = a.v0;
	}

	inline _AqronosPoint(double x, double y, double z, uint8_t r, uint8_t g, uint8_t b)
	{
		this->x = x; this->y = y; this->z = z;
		this->r = r; this->g = g; this->b = b;
		this->point_moving = false;
		this->point_in_vel_window = false;
		this->v0 = 0;
	}

	inline _AqronosPoint(double x, double y, double z)
	{
		this->x = x; this->y = y; this->z = z;
		this->r = 255; this->g = 255; this->b = 255;
		this->point_moving = false;
		this->point_in_vel_window = false;
		this->v0 = 0;
	}

	EIGEN_MAKE_ALIGNED_OPERATOR_NEW

} EIGEN_ALIGN16;


POINT_CLOUD_REGISTER_POINT_STRUCT (_AqronosPoint,
					(float, x, x)
					(float, y, y)
					(float, z, z)
					(uint32_t, rgb, rgb)
					(uint8_t, avg_int, avg_int)
					(double, vel, vel)
					(double, radius, radius)
					(float, theta, theta)
					(float, phi, phi)
					(int, w, w)
					(int, h, h)
					(uint8_t, point_moving, point_moving)
					(uint8_t, point_in_vel_window, point_in_vel_window)
					(double, v0, v0)
)

// PCL_INSTANTIATE(KdTree, _AqronosPoint);
// PCL_INSTANTIATE(KdTreeFLANN, _AqronosPoint);
// PCL_INSTANTIATE(OctreePointCloudSearch, _AqronosPoint);
// PCL_INSTANTIATE(pcl::PCLBase, _AqronosPoint);



typedef _AqronosPoint AqronosPoint;
//typedef pcl::PointXYZRGB AqronosPoint;

inline void PrintPoint(const AqronosPoint &p)
{
	std::cout << "     x: " << p.x;
	std::cout << "	y: " << p.y;
	std::cout << "  z: " << p.z << std::endl;
	std::cout << "     vel: " << (int) p.vel << "   rad: " << (int) p.radius << "  int: " << (int) p.avg_int << std::endl;
	std::cout << "     theta: " << p.theta << "   phi: " << p.phi << std::endl;
}

inline double Dist(const AqronosPoint &p0, const AqronosPoint &p1)
{
	return sqrt( pow(p0.x - p1.x,2) + pow(p0.y - p1.y,2) + pow(p0.z - p1.z,2) );
}



#endif // AQRONOS_POINT_INCLUDE