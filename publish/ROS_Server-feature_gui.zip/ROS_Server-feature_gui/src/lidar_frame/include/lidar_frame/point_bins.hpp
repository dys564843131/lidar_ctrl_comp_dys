/*	point_bins.hpp
 * 
 * Bundle together some fields for a filtering queue
 * Along with some predefiend filter functions
 * And ROS publishers
 *
 * maintainer: Nathan Corral (nathan@aqchronos.com)
*/
#ifndef POINT_BINS_INCLUDE_HPP 
#define POINT_BINS_INCLUDE_HPP


#include "lidar_frame/aqronos_point.hpp"
#include <vector>

#include <pcl_ros/point_cloud.h>
#include <pcl/point_types.h>

#include <iostream>

#define POINTS_PER_DIST 0.05

/* Class for storing indexes of points into generated point cloud */
class Bin
{
	public:
		Bin(pcl::PointCloud<AqronosPoint>::Ptr _data);

		void push_back(int in);

		void Merge(Bin& other);

		int at(int idx);

		bool CheckDist(const double max_dist, Bin &other );

		bool CheckMinDist(const double max_dist, int point_idx);

		bool CheckMinDist(const double max_dist, AqronosPoint &p);

		bool CheckDistExact(const double max_dist, Bin &other );

		bool CheckMinDistExact(const double max_dist, int point_idx);

		bool empty();

		size_t size();

		double GetAvgDist();

		void GetBoundingBox(pcl::PointCloud<AqronosPoint>::Ptr bounding_box);

		/* Returns Exact minimum distance between points of bin */
		float MinDist(AqronosPoint p);

		/* Returns the aprox minimum distance points of two bins */
		float operator-(Bin& other);

		// Bin& operator+(const Bin& other);

		// Bin& operator+=(const Bin& other);
		AqronosPoint centroid;	

		private:

		/* Indexes into Point cloud */
		std::vector<int> idxs;

		/* Pointer to point cloud */
		pcl::PointCloud<AqronosPoint>::Ptr _data;

		/* Extra data about points in bin */
		float min_x;
		float max_x;
		float min_y;
		float max_y;
		float min_z;
		float max_z;
		

		double avg_dist = -1;

};


#endif // AQRONOS_PC_INCLUDE_HPP