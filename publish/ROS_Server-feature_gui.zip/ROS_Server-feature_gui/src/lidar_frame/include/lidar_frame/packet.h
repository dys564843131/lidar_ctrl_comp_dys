#ifndef AQRONOS_PACKET_H_INCLUDED 
#define AQRONOS_PACKET_H_INCLUDED 

#include <stdbool.h>
#include <memory>

#pragma pack(push)
#pragma pack(1)

#define POINTS_PER_UDP_PACKET 300

struct UDPHeader
{
	uint16_t SourcePort;
	uint16_t DestPort;
	uint16_t Length;
	uint16_t Checksum;
} __attribute__((packed)) ;

struct AqronosPacketHeader
{
	//uint16_t magic_number;
	uint32_t frame_counter;
} __attribute__((packed)) ;

struct AqronosPacketData
{
	_Bool TrigI			:	1;
	_Bool TrigB			:	1;
	_Bool TrigA			:	1;
	uint32_t avg_int	:	5;
	uint32_t velocity	:	12;
	uint32_t radius		:	12;
} __attribute__((packed)) ;

struct AqronosPacket
{
	AqronosPacketHeader header;
	AqronosPacketData data[POINTS_PER_UDP_PACKET];
} __attribute__((packed)) ;


#pragma pack(pop)


#endif // AQRONOS_PACKET_H_INCLUDED