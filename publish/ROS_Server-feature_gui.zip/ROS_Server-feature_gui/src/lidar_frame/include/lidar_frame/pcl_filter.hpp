#ifndef AQRONOS_PCL_FILTER_H_INCLUDED 
#define AQRONOS_PCL_FILTER_H_INCLUDED 

/* ROS includes */
#include "ros/ros.h"
#include <dynamic_reconfigure/server.h>
#include <sensor_msgs/PointCloud2.h>
#include <pcl_conversions/pcl_conversions.h>

#include "lidar_frame/aqronos_pc.hpp"
#include <lidar_frame/pcl_filterConfig.h> /* CFG Params */

#include <queue>
#include <mutex>
#include <thread>
#include <chrono>

class Filter_PCL
{
	public:
		Filter_PCL(ros::NodeHandle &n);
		~Filter_PCL();
	
	private:
		void Filter(const sensor_msgs::PointCloud2::ConstPtr& pc);

		int width, height;

		void TimerCallback(const ros::TimerEvent& event);

		void ApplyFilter(std::shared_ptr<AqronosPointCloud> &pc);

		void PublishNext();
		
		std::queue<std::shared_ptr<AqronosPointCloud>> pc_queue;
		std::mutex queue_mutex;

		/* Ground Plane Params/Vars */
		std::thread find_ground_thread;
		void FindGroundPlaneThread();
		void AdjustGroundPlane(std::shared_ptr<AqronosPointCloud> &pc);
		pcl::ModelCoefficients::Ptr ground_coeff;
		pcl::ModelCoefficients::Ptr test_ground_coeff;
		std::mutex ground_frame_mutex;
		std::shared_ptr<AqronosPointCloud> ground_frame = NULL;


		/**** Ros Parameters ****/
		ros::Subscriber pc_sub;
		ros::Publisher pc_pub;
		ros::Publisher bounding_box_pub;
		ros::Publisher keypoint_pub;
		ros::NodeHandle * nh;
		ros::Timer publish_timer;
		/*************************/

		/**** Dynamically Reconfigure Params ***/
		lidar_frame::pcl_filterConfig params;
		dynamic_reconfigure::Server<lidar_frame::pcl_filterConfig> server;
		dynamic_reconfigure::Server<lidar_frame::pcl_filterConfig>::CallbackType f;
		void CFGCallback(const lidar_frame::pcl_filterConfig &config, uint32_t level);
		/***************************************/

		/* Logging Params */
		ros::Time last_timer_callback;
};

#endif
