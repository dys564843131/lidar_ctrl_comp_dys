#ifndef AQRONOS_FILTER2D_FILTER_H_INCLUDED 
#define AQRONOS_FILTER2D_FILTER_H_INCLUDED 

/* ROS includes */
#include "ros/ros.h"
#include <dynamic_reconfigure/server.h>

#include <lidar_frame/frame.h> /* Frame msg */
#include <lidar_frame/filter2dConfig.h> /* CFG Params */

#include <vector>
#include <queue>
#include <numeric> // iota

class Filter2d
{
	public:
		Filter2d(ros::NodeHandle &n);
	
	private:
		void Filter(const lidar_frame::frame::ConstPtr& f);

		void CFGCallback(lidar_frame::filter2dConfig &config, uint32_t level);

		void MedianFilterSlow(const std::vector<double> &in, std::vector<double> &out);

		void MedianFilter(const std::vector<double> &in, std::vector<double> &out);
		void MedianHelper(std::vector<double>& window, double left, double right);

		void Median2d(const std::vector<double> &in, std::vector<double> &out, const int height, const int width);

		lidar_frame::filter2dConfig params;

		/**** Ros Parameters ****/
		ros::Subscriber frame_sub;
		ros::Publisher frame_pub;
		ros::NodeHandle * nh;
		/*************************/

		/**** Dynamically Reconfigure Params ***/
		dynamic_reconfigure::Server<lidar_frame::filter2dConfig> server;
		dynamic_reconfigure::Server<lidar_frame::filter2dConfig>::CallbackType f;
		/***************************************/
};

#endif
