#ifndef RING_HPP_INCLUDED 
#define RING_HPP_INCLUDED 

#define RADIAN_RING_HPP(x) (x * PI / 180.0)
#define PI 3.1415

#define TEXT_SCALE 1.4 // Size of text
#define TEXT_ALPHA 0.45 // Transparency of text. [0 : 1]
#define TEXT_R 1.0f // RGB of text
#define TEXT_G 1.0f
#define TEXT_B 1.0f

#define POINT_PER_RING 50
#define CIRCLE_SCALE 0.02 // Size of points on ring


#include <pcl/point_types.h>
#include <visualization_msgs/Marker.h>
#include <geometry_msgs/Point.h>

#include <pcl/point_types.h>

#include <iomanip> // setprecision
#include <sstream> // stringstream


class Ring
{
public:
	Ring( double radius, geometry_msgs::Point center) :
 	radius(radius),
 	center(center)
 	{
 		circle.type = visualization_msgs::Marker::LINE_STRIP;
 		text.type = visualization_msgs::Marker::TEXT_VIEW_FACING;
 		circle.action = text.action = visualization_msgs::Marker::ADD;
 		// center.x = 0;
 		// center.y = 0;
 		// center.z = -5;
 		SetTextDegree(30);
 		BuildRing();
 	}

 	void SetTextDegree(double degree)
 	{
 		text_theta = RADIAN_RING_HPP(degree); 
 	}

 	void BuildRing()
 	{
 		double theta = 0;
 		for(int i=0; i<POINT_PER_RING; ++i, theta+=(2.0*PI)/((double) POINT_PER_RING))
 		{
 			geometry_msgs::Point p;
 			p.x = radius * cos(theta) + center.x;
 			p.y = radius * sin(theta) + center.y;
 			p.z = center.z;
 			circle.points.push_back(p);
 		}

 		/* Complete circle */
 		/* Add origin for lable text */
 		geometry_msgs::Point p;
		p.x = radius + center.x;
		p.y = center.y;
		p.z = center.z;

		text.pose.position.x = radius * cos(text_theta) + center.x;
		text.pose.position.y = radius * sin(text_theta) + center.y;
		text.pose.position.z = center.z;
		circle.points.push_back(p);

		if(radius >= 50)
		{
			text.scale.x = 1.3*TEXT_SCALE; 
 			text.scale.y = 1.3*TEXT_SCALE; 
 			text.scale.z = 1.3*TEXT_SCALE;
		}
		else
		{
			text.scale.x = TEXT_SCALE; 
 			text.scale.y = TEXT_SCALE; 
 			text.scale.z = TEXT_SCALE;
		}
 		

 		circle.scale.x = CIRCLE_SCALE;
 		circle.scale.y = CIRCLE_SCALE;
 		circle.scale.z = CIRCLE_SCALE;

 		// Set the frame ID and timestamp.  See the TF tutorials for information on these.
		text.header.frame_id = circle.header.frame_id = "/world";
		text.header.stamp = circle.header.stamp = ros::Time::now();

		// Set the namespace and id for this marker.  This serves to create a unique ID
		// Any marker sent with the same namespace and id will overwrite the old one
		circle.ns = "Circle";
		circle.id = radius;
		text.ns = "Text";
		text.id = radius;

		// Set the pose of the marker.  This is a full 6DOF pose relative to the frame/time specified in the header
		circle.pose.position.x = 0;
		circle.pose.position.y = 0;
		circle.pose.position.z = 0;
		text.pose.orientation.x = circle.pose.orientation.x = 0.0;
		text.pose.orientation.y = circle.pose.orientation.y = 0.0;
		text.pose.orientation.z = circle.pose.orientation.z = 0.0;
		text.pose.orientation.w = circle.pose.orientation.w = 1.0;


		// Set the color -- be sure to set alpha to something non-zero!
		text.color.r = circle.color.r = TEXT_R;
		text.color.g = circle.color.g = TEXT_G;
		text.color.b = circle.color.b = TEXT_B;
		text.color.a = circle.color.a = TEXT_ALPHA;

		text.lifetime = circle.lifetime = ros::Duration();

		std::stringstream s;
		s << std::fixed << std::setprecision(1) << radius << "m";
		text.text = s.str();
 	}


 	visualization_msgs::Marker circle;
	visualization_msgs::Marker text;

private:
	geometry_msgs::Point center;
	double radius;
	double text_theta;
	};

#endif // RING_HPP_INCLUDED