#ifndef UDP_PACKET_H_INCLUDED 
#define UDP_PACKET_H_INCLUDED 

/* ROS includes */
#include "ros/ros.h"
#include <dynamic_reconfigure/server.h>

#include <lidar_frame/frame.h> /* Frame msg */
#include <lidar_frame/packet.h>
#include <lidar_frame/udp_frameConfig.h>

/* Boost includes */
#include <boost/asio.hpp> // For udp sockets
#include <boost/io/ios_state.hpp> // ios_all_saver for printing hex
#include <boost/bind.hpp> // For binding packet handler

/* Std includes */
#include <numeric> // accumulate
#include <string>
#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <vector>
#include <iomanip>
#include <bitset>
#include <queue>

#define FRAME_BUFFER 100 
#define FRAME_PUB_ID "/udp_packet/udp_frame"

using boost::asio::ip::udp;

class UDPPacket
{
	public:
		UDPPacket(std::string host, short port, ros::NodeHandle &n);
				
		void PrintRawData(int length);

		/* Functions for recieving udp packets */
		void Receive();

		/* Deseralize and add data to frame */
		void DeserializeData(int udp_idx = 0);

		void PublishFrame(std::shared_ptr<lidar_frame::frame> & f);

		/* Callback for Getting params */
		// void GetParamsCB(const ros::TimerEvent& event);
	
	private:

		void SetFrameParams();

		void FrameInit();

		void FrameReset();

		void SaveUDPToFile(std::string file_name, int bytes_transfered);

		/* Check difference between frame_tracker and recieved frame offset of each packet */
		void CheckUDPError(int frame_check);

		void add_to_vector(const double & val, const int & idx, std::vector<double> & vec);
		void add_to_vector(const uint32_t & val, const int & idx, std::vector<uint8_t> & vec);

		/* Helper Functions for recieving udp packets */
		void packet_handler(const boost::system::error_code& err, std::size_t bytes_transfered);
		
		/* Wrapper function for async packet handler */
		void do_receive();

		double process_rad(uint16_t r_in, int idx);

		/* v0 is the velocity of the spinning mirrors which deflect the lidar */
		/* It is calculated for each row */
		/* It is calculated in the first frame when nothing is moving and subtracted from proceeding velociteis */
		void UpdateV0(const std::shared_ptr<lidar_frame::frame> & f);
		std::vector<double> v0;
		std::vector<double> v0_count;
		bool v0_found = false;
		//double v0_count = 0;
		double process_vel(uint16_t v_in, int idx);

		/* UPD INFO */
		udp::endpoint sender_endpoint_;
		boost::asio::io_service io_service;
		udp::socket socket_;
		AqronosPacket data[50];

		/* Ros Data */
		ros::Publisher frame_pub;
		ros::NodeHandle * n;
		ros::Timer timer;

		/* Offset for reset of frame counter */
		int frame_counter_offset = 0;

		/* Frame & Packet Info */
		uint32_t frame_counter;
		int triggerI_count = 0;
		std::shared_ptr<lidar_frame::frame> frame;


		/**** Ros Parameters ****/
		// void GetParams();
		int UDPNumPackets = 0;
		int packet_counter = 0;
		double info_time = 5;

		/* Global Params used by Packet Server */
		int frame_rows_tracker = 40;
		int frame_cols_tracker = 1250;
		void UpdateGlobalParams();
		/*************************/

		/**** Dynamically Reconfigure Params ***/
		lidar_frame::udp_frameConfig params;
		dynamic_reconfigure::Server<lidar_frame::udp_frameConfig> server;
		dynamic_reconfigure::Server<lidar_frame::udp_frameConfig>::CallbackType f;
		void CFGCallback(const lidar_frame::udp_frameConfig &config, uint32_t level);

		/* Defaults since parameters are only reset at every new frame */
		int NUM_TRIG_I = 7;
		bool UseTrigger = false;
		bool OnlyTrigA = false;
		bool UseTrigB = false;

		int v0_frame_count = 0;

		/***************************************/
		// Type so it overflows at the same time as frame_offset
		uint32_t frame_tracker = 0;
};

#endif
