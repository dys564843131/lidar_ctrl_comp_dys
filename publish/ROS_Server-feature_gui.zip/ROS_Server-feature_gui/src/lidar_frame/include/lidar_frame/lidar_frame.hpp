#ifndef LIDAR_FRAME_H_INCLUDED 
#define LIDAR_FRAME_H_INCLUDED 

#include "ros/ros.h"
#include <sensor_msgs/PointCloud2.h>
#include <pcl_conversions/pcl_conversions.h>
#include <pcl_ros/point_cloud.h>

#include <pcl/common/common.h> // GetMinMax

#include <dynamic_reconfigure/server.h>
#include <lidar_frame/pointcloudConfig.h>

#include <lidar_frame/frame.h> /* Frame msg */
#include "lidar_frame/aqronos_point.hpp"
// #include "lidar_frame/ring_list.hpp"

#include <string>
#include <stdlib.h>
#include <iostream>
#include <algorithm> // rotate
#include <numeric> // iota

#define PI 3.1416
#define RADIAN(x) (x * PI / 180.0)
#define DEGREE(x) x * 180.0 / PI

#define FRAME_BUFFER_SIZE 100

#define POLYGON_FACES 6

//#define DEGREE_TRIG_A 0.48 // 1.44 / 3
//#define NUM_TRIG_A_PER_LINE 250 // 83.3333 * 3
#define NUM_TRIG_A_PER_LINE 50 // 83.3333 * 3


class LidarFrame
{
	public:
		LidarFrame(ros::NodeHandle &n);

		~LidarFrame();
	
	private:

		void CFGCallback(lidar_frame::pointcloudConfig &config, uint32_t level);

		/* Populate Point Cloud from frame */
		void BuildPC(const lidar_frame::frame::ConstPtr& f);

		/* ROS Callback for recieved Frame */
		void FrameCallback(const lidar_frame::frame::ConstPtr& f);

		/* Calculate Polar Coordinate Angles */
		//void CalcThetaPhi();

		bool UseTriggers(const lidar_frame::frame::ConstPtr& f);
		void CalcPhi(const lidar_frame::frame::ConstPtr& f);
		void CalcTheta(const lidar_frame::frame::ConstPtr& f);
		void AddPhiLine(int row_points, double delay = -1);
		void CalcPhiTriggers(const lidar_frame::frame::ConstPtr& f);

		void Normalize(std::vector<double> &out, const std::vector<double> &in);
		int MaxIndex(const std::vector<double>& arr);


		/* Same as matlab except it pushes to back of vector */
		void linspace(const double min, const double max, const int n, std::vector<double> &vec);

		void ClusterPoints( const std::vector<double> & vel, std::shared_ptr<pcl::PointCloud<AqronosPoint>> pc );

		void RemoveOutsideWindowPhi(std::vector<size_t> & idx, const std::vector<double> & vel, const std::shared_ptr<pcl::PointCloud<AqronosPoint>> pc);
		void RemoveOutsideWindow(std::vector<size_t> & idx, const std::vector<double> & vel, const std::shared_ptr<pcl::PointCloud<AqronosPoint>> pc);
		void RemoveOutsideWindowFrame(std::vector<size_t> & idx, const std::vector<double> & vel, const std::shared_ptr<pcl::PointCloud<AqronosPoint>> pc);

		/* ROS Objects */
		ros::Subscriber frame_sub; // Recieve frames from udp_server client 
		ros::Publisher pc_pub_raw;	// Publish under topic /'$node_name'/'$pc_topic'
		ros::NodeHandle * nh;

		int frames_recv = 0;
		int frames_handled = 0;

		/*********************************/
		/* ROS Server Parameters */
		/* Default values should be set in the ros-launch file which over writes these*/
		float ratio = 0.2;
		float y_delay = 0.21;
		float x_delay = 0.98;
		float y_angle0 = -4.0;
		float y_angle1 = 1.0;
		float x_angle = 90;
		float degree_trig_a;

		float x_offset;
		float y_offset;

		bool SinScan;

		int frame_rows = 40;
		int frame_cols = 1250;
		int frame_max_points;

		bool OnlyTrigA;
		bool UseTrigger;

		bool DumpPhiTheta = false;

		/*********************************/

		/* Angles for converting from Polar to Cartitian Coordinates */
		std::vector<double> theta;
		int theta_index = 0;
		std::vector<double> phi;
		double min_phi, max_phi;

		lidar_frame::pointcloudConfig params;
		dynamic_reconfigure::Server<lidar_frame::pointcloudConfig> server;
		dynamic_reconfigure::Server<lidar_frame::pointcloudConfig>::CallbackType f;


		volatile bool config_change = false;


};

#endif
