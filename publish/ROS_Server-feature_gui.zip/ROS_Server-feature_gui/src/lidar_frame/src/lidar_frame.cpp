#include "lidar_frame/lidar_frame.hpp"

LidarFrame::LidarFrame(ros::NodeHandle &n) :
	server{n}
{
	nh = &n;	

	f = boost::bind(&LidarFrame::CFGCallback, this, _1, _2);
	server.setCallback(f);

	/* Initialize params and theta, then add callbacks */
	frame_sub = nh->subscribe("/median_filter/filt_frame", FRAME_BUFFER_SIZE, &LidarFrame::FrameCallback, this);
	pc_pub_raw = nh->advertise<sensor_msgs::PointCloud2>("/lidar_frame/pointcloud_raw", 10);

	frame_rows = frame_cols = 0;
}

LidarFrame::~LidarFrame()
{

}

void LidarFrame::CFGCallback(lidar_frame::pointcloudConfig &config, uint32_t level)
{
	// median_window_size = config.median_window_size;
	y_delay = config.y_delay;
	x_delay = config.x_delay;
	y_angle0 = config.y_angle0;
	y_angle1 = config.y_angle1;
	x_angle = config.x_angle;
	x_offset = config.x_offset;
	y_offset = config.y_offset;
	SinScan = config.SinScan;
	config_change = true;
	params = config;
}



void LidarFrame::linspace(const double min, const double max, const int n, std::vector<double> &vec)
{
	double delta = (max - min) / static_cast<double>(n-1);
	double val = min;
	for(int i = 0; i < n; ++i, val += delta)
	{	
		vec.push_back( val );	
	}
}

void LidarFrame::CalcTheta(const lidar_frame::frame::ConstPtr& f)
{
	theta.clear();
	theta.reserve(f->num_points);

	/* Construct theta vector, secion 0 */
	linspace( RADIAN( y_angle0 ), RADIAN( y_angle1 ), floor(params.ratio * f->num_points), theta);
	/* Construct theta vector, secion 1 */
	linspace( RADIAN( y_angle1 ), RADIAN( y_angle0 ), ceil((1 - params.ratio) * f->num_points), theta);
	/* Circular Shift */
	std::rotate(theta.begin(), theta.begin() + theta.size() - floor(y_delay * f->num_points), theta.end());	
}

void LidarFrame::CalcPhiTriggers(const lidar_frame::frame::ConstPtr& f)
{
	double avg_num_points; // per side of polygon

	/* Get average number of points per row */
	/* Ignore zero and frame->num_points triggers */
	std::vector<int> vec_row_points;
	for(int trig_idx=1; trig_idx<f->triggerA.size()-2; ++trig_idx)
	{
		int row_points = roundf((f->triggerA.at(trig_idx+1) - f->triggerA.at(trig_idx)) / ((double) POLYGON_FACES));
		vec_row_points.push_back(row_points);
	}
	avg_num_points = std::accumulate(vec_row_points.begin(), vec_row_points.end(), 0.0);
	avg_num_points /= (double) vec_row_points.size();
	// ROS_ERROR_STREAM("AVG Num Points: " << avg_num_points);


	/* Add to phi array */
	for(int trig_idx=0; trig_idx<(f->triggerA.size()-1); ++trig_idx)
	{
		int trigger_points = f->triggerA.at(trig_idx+1) - f->triggerA.at(trig_idx);
		// std::cout << "Trig IDX: " << trig_idx << "   Num Points:  " << trigger_points << std::endl;
		int num_polygon_sides;

		if( trig_idx == 0 || trig_idx == (f->triggerA.size()-2) )
		{
			/* First and Last trigger not garenteed to have all polygon sides 
			 * because we artifitially set a trigger at the beginning and end of a line.
			 * ie. 6 sided polygon could have 2 sides scanned when galvo completed the frame
			 * then the first trigger section of the next frame would only have 4 polygon sides.
			 *
			 * Try and guess number of polygon sides scanned */
			int leftover_points = trigger_points;
			int polygon_sides_scanned = 1;
			for(int pss=1; pss<=POLYGON_FACES; ++pss) // pss: polygon sides scanned
			{
				int count_leftover_points = abs( trigger_points - (pss*avg_num_points) ) ;
				if(count_leftover_points < leftover_points)
				{
					leftover_points = count_leftover_points;
					polygon_sides_scanned = pss;
				}
			}

			/* Divide the number of points between triggers by this */
			num_polygon_sides = polygon_sides_scanned;
			// std::cout << "Trig IDX: " << trig_idx << "   Num Sides:  " << num_polygon_sides << std::endl;
		}
		else
		{
			/* Assume all polygon sides got scanned */
			num_polygon_sides = POLYGON_FACES;
		}

		// ROS_ERROR_STREAM("EXTRA POINTS: " << (trigger_points % num_polygon_sides));
		/* For each row scanned, interpolate the points and add to phi vector */
		for(int row=0; row<num_polygon_sides; ++row)
		{
			int row_points = floor((double) trigger_points / ((double) num_polygon_sides));
			/* Add extra point(s) to beginning of each row. 
			 * Accounts for floor divide above 
			 */
			if( row < (trigger_points % num_polygon_sides) )
			{
				// ROS_ERROR_STREAM((trigger_points % num_polygon_sides) << "  <  " << row);
				row_points++;
			}

			// std::cout << "row: " << row << std::endl;
			AddPhiLine(row_points);
		}
	}
}


void LidarFrame::AddPhiLine(int row_points, double delay)
{
	// std::cout << "Adding " << row_points << "  points" << std::endl;
	double phi_min, phi_max;
	if(SinScan)
	{
		phi_min = 0; 
		phi_max = 2*PI;
	}
	else
	{
		phi_max = RADIAN(x_angle / 2.0);
		phi_min = -phi_max;
	}

	if( delay >= 0 )
	{
		x_delay = delay;
	}
	else
	{
		x_delay = params.x_delay;
	}

	/* Add points to phi vector in two parts, shifted by x delay */
	int points_first = floor(row_points * x_delay);
	linspace( phi_min + (phi_max - phi_min) * (1 - x_delay), phi_max, points_first, phi);
	linspace( phi_min, phi_min + (phi_max - phi_min) * (1 - x_delay), row_points - points_first, phi);
}


void LidarFrame::CalcPhi(const lidar_frame::frame::ConstPtr& f)
{
	
	phi.clear();
	if( UseTriggers(f) )
	{
		CalcPhiTriggers( f );
	}
	else
	{
		//std::cout << "LF   Frame Points: " << f->num_points << "  Rows: " << f->frame_rows  << "   Cols: " << f->frame_cols << std::endl;
		double delay;
		if( params.AutoXdelay )
		{
			int max_idx = MaxIndex(f->v0);
			delay = ((max_idx) / floor((double) f->frame_cols));
		}
		else
		{
			delay = -1;
		}
		
		//std::cout << "  Largest idx: " << max_idx << "  Val: " << f->v0[max_idx] << "   X delay: " << delay << std::endl;
		for(int row=0; row<f->frame_rows; ++row)
		{
			int row_points = floor((double) f->num_points / ((double) f->frame_rows));
			// Add extra points to beginning frame rows
			if( row < (f->num_points % f->frame_rows) )
			{
				row_points++;
			}

			AddPhiLine( row_points, delay );
		}
	}

	ROS_ASSERT(phi.size() == f->num_points);
}

int LidarFrame::MaxIndex(const std::vector<double>& arr)
{
	int idx = 0;
	for(int i=1; i<arr.size(); ++i)
	{
		if( ! std::isnan(arr[i]) && arr[i] > arr[idx] )
		{
			idx = i;
		}
	}
	return idx;
}

bool LidarFrame::UseTriggers(const lidar_frame::frame::ConstPtr& f)
{
	// Check if number of rows match number of triggers recieved.
	return (f->frame_rows == (f->triggerA.size() - 1)) &&
			(f->triggerA.size() > 3);
}

void LidarFrame::BuildPC(const lidar_frame::frame::ConstPtr& f)
{

	// ros::Time n = ros::Time::now();
	frame_rows = f->frame_rows;
	frame_cols = f->frame_cols;

	std::shared_ptr<pcl::PointCloud<AqronosPoint>> pc(new pcl::PointCloud<AqronosPoint>);

	std::vector<double> noramlized_int;
	if( params.VelocityScale )
	{
		Normalize(noramlized_int, f->velocity);
	}
	else if( params.IntensityScale )
	{
		std::vector<double> doubleVec(f->avg_intensity.begin(), f->avg_intensity.end());
		Normalize(noramlized_int, doubleVec);
	}

	double cur_phi = 0;

	if(f->num_points != phi.size() || config_change || UseTriggers(f) )
	{
		config_change = false;
		CalcPhi(f);
		CalcTheta(f);
	}

	std::ofstream phi_out, theta_out;
	if( DumpPhiTheta )
	{
		phi_out.open("phi.txt");
		theta_out.open("theta.txt");
	}

	double x_offset_rad = RADIAN(x_offset);
	double x_angle_rad = RADIAN(x_angle);
	double y_offset_rad = RADIAN(y_offset);

	std::vector<double> cluster_vel;

	max_phi = -1000.0;
	min_phi = 1000.0;
	int zero_count=0;
	for(int i = 0 ; i < f->num_points; i++)
	{
		if( SinScan )
		{
			//cur_phi = RADIAN( (x_angle * sin(phi.at(i % phi.size())))) + x_offset_rad;
			cur_phi =  (x_angle_rad * sin(phi.at(i % phi.size()))) + x_offset_rad;
		}
		else
		{
			cur_phi = ( phi.at(i % phi.size()) + x_offset_rad);
		}

		// double cur_theta = theta[theta_index % theta.size()] + y_offset_rad;
		double cur_theta = theta[i % theta.size()] + y_offset_rad;
		theta_index++;

		if( DumpPhiTheta )
		{
			phi_out << cur_phi << std::endl;
			theta_out << cur_theta << std::endl;
		}
		

		AqronosPoint p;
		if( std::isnan(f->radius.at(i)) || std::isnan(f->velocity.at(i)) )
		{
			p.x = std::numeric_limits<float>::quiet_NaN();
			p.y = std::numeric_limits<float>::quiet_NaN();
			p.z = std::numeric_limits<float>::quiet_NaN();
			cluster_vel.push_back(std::numeric_limits<float>::quiet_NaN());
			p.vel = 0;
			p.v0 = 0;
			zero_count++;
		}
		else
		{


			if( params.TaekVel )
			{
				double cur_phi_degree = DEGREE( phi.at(i % phi.size()) );
				double vel_cancel;
				vel_cancel = abs(0.00004*pow(cur_phi_degree, 3.0) - 0.0024*pow(cur_phi_degree, 2.0) + 0.1466*cur_phi_degree + 2.4894);
				vel_cancel *= params.TaekScale;
				vel_cancel += params.TaekOffset;

				cluster_vel.push_back(f->velocity.at(i) - vel_cancel);
				p.vel = f->velocity.at(i) - vel_cancel;
				p.v0 = vel_cancel;

			}
			else
			{
				cluster_vel.push_back(f->velocity.at(i));
				p.vel = f->velocity.at(i);
				p.v0 = f->v0.at(i);
			}

			p.x = ((double) f->radius.at(i)) * cos(cur_theta) * cos(cur_phi);
			p.y = ((double) f->radius.at(i)) * cos(cur_theta) * sin(cur_phi);
			p.z = ((double) f->radius.at(i)) * sin(cur_theta);
		}
		

		p.avg_int = f->avg_intensity.at(i);
		p.radius = f->radius.at(i);
		p.theta = cur_theta;
		p.phi = cur_phi;

		max_phi = std::max(max_phi, cur_phi); 
		min_phi = std::min(min_phi, cur_phi); 

		p.r = 255;
		p.b = 255;
		p.g = 255;
		p.point_moving = false;
		p.point_in_vel_window = false;


		if( noramlized_int.size() == f->num_points )
		{
			p.r *= std::min(1.0, params.ScaleOffset + noramlized_int.at(i));
			p.b *= std::min(1.0, params.ScaleOffset + noramlized_int.at(i));
			p.g *= std::min(1.0, params.ScaleOffset + noramlized_int.at(i));
		}

		if(f->frame_cols != 0)
		{
			p.w = i % f->frame_cols; 
			p.h = floor(i / ((double) f->frame_cols));
		}

		pc->push_back(p);
	}

	if( DumpPhiTheta )
	{
		theta_out.close();
		phi_out.close();
	}
	DumpPhiTheta = params.DumpPhiTheta;


	if( ! UseTriggers(f) && (f->num_points % f->frame_rows == 0) )
	{
		pc->is_dense = false;
		pc->width = f->num_points / f->frame_rows;
		pc->height = f->frame_rows;
	}
	
	
	ClusterPoints(cluster_vel, pc);
	ROS_WARN_STREAM_THROTTLE(1, "[Lidar Frame]: Num Points: " << f->num_points << ".   Real Data Points: " << f->num_points - zero_count);

	/* Publish Raw Point Cloud Msg */
	ROS_INFO_STREAM_ONCE("[Lidar Frame]:  Transmitting Point Clouds...");
	sensor_msgs::PointCloud2 msg;
	pcl::toROSMsg(*pc, msg);
	msg.header = f->header;
	msg.header.frame_id = "world";

	pc_pub_raw.publish(msg);

	ROS_INFO_STREAM_DELAYED_THROTTLE(1,"[Lidar Frame]:  Non-Filter Processing Time: " << (ros::Time::now() - msg.header.stamp).toSec() << "s");
}


void LidarFrame::FrameCallback(const lidar_frame::frame::ConstPtr& f)
{
	BuildPC(f);
	frames_recv++;
}

void LidarFrame::Normalize(std::vector<double> &out, const std::vector<double> &in)
{
	double ma = *std::max_element(in.begin(), in.end());
	double mi = *std::min_element(in.begin(), in.end());

	for(int i=0; i<in.size(); ++i)
	{
		out.push_back( (in[i] - mi) / (ma - mi) );
	}
}


void LidarFrame::ClusterPoints( const std::vector<double> & vel, std::shared_ptr<pcl::PointCloud<AqronosPoint>> pc )
{
    if( vel.empty() )
    {
        return;
    }

    // initialize original index locations
    std::vector<size_t> idx(pc->points.size());
    std::iota(idx.begin(), idx.end(), 0);

    RemoveOutsideWindowPhi(idx, vel, pc);
	//RemoveOutsideWindow(idx, vel, pc);
	//RemoveOutsideWindowFrame(idx, vel, pc);

	/* Mark points in velocity window */
    for(auto i : idx)
    {
    	pc->points.at(i).point_in_vel_window = true;
    }

    if( ! params.FilterVel )
	{
		return;
	}

    if(idx.size() == 0)
    {
        return;
    }

    // sort indexes based on comparing values in v
    std::sort(idx.begin(), idx.end(),
    [&vel](size_t i1, size_t i2) {return vel[i1] < vel[i2];});

    // Vector indexes for discontinuities in sorted velocity 
    std::vector<int> discont;
    // add start location
    discont.push_back(0);

    // Search for discontinuities larger than FilterVelClusterSize
    double prev = vel.at(idx.at(0));
    for(int i=1; i<idx.size(); ++i)
    {
        double diff = vel.at(idx.at(i)) - prev;
        if(diff > params.FilterVelClusterDist)
        {
            // mark location
            discont.push_back(i);
        }
        prev = vel.at(idx.at(i));
    }

    // add end location
    discont.push_back(idx.size());

    // Get count of largest cluster.  Largest cluster is not moving
    // dist_count gives number of clusters found
    int dist_count = 0;
    int largest_count = 0;
    for(int i=1; i<discont.size(); ++i)
    {
        largest_count = std::max(largest_count, discont.at(i) - discont.at(i-1));
        if(discont.at(i) - discont.at(i-1) > params.FilterVelMinClusterSize)
        {
            dist_count++;
        }
    }

    // ROS_WARN_STREAM("Number of discont: " << dist_count << "  Largest:  " << largest_count);

    // Color groups of discontinuities together
    for(int i=1; i<discont.size(); ++i)
    {
        int num_points = discont.at(i) - discont.at(i-1);
        //std::cout << "Cluster: " << i << "   Number of points: " << num_points << "        ";
        //std::cout << "Min:  " << pc->points.at( idx.at(discont.at(i-1)) ).vel << " Max:  " << pc->points.at( idx.at(discont.at(i) - 1) ).vel << std::endl;
        // Skip largest cluster, or if clusting is 80 % as large as largest cluster
        if(num_points >= (0.2 * largest_count))
        {
            continue;
        }

        if(num_points > params.FilterVelMinClusterSize)
        {
            for(int j=discont.at(i-1); j<discont.at(i); ++j)
            {
            	if( pc->points.at( idx.at(j) ).vel != 0 && ! std::isnan(pc->points.at(idx.at(j)).vel ) )
                	pc->points.at( idx.at(j) ).point_moving = true;
            }
        }
    }
}

void LidarFrame::RemoveOutsideWindowPhi(std::vector<size_t> & idx, const std::vector<double> & vel, const std::shared_ptr<pcl::PointCloud<AqronosPoint>> pc)
{
	double length = max_phi - min_phi;
	double width = ((params.VelWindow/200.0) * length);
	double max_phi_scale = max_phi - width;
	double min_phi_scale = min_phi + width;

	idx.erase(std::remove_if(idx.begin(), idx.end(), 
        [=](size_t i) {
        	return std::isnan(vel[i]) || (pc->points.at(i).phi < min_phi_scale) || (pc->points.at(i).phi > max_phi_scale);
        }), idx.end());
}

void LidarFrame::RemoveOutsideWindow(std::vector<size_t> & idx, const std::vector<double> & vel, const std::shared_ptr<pcl::PointCloud<AqronosPoint>> pc)
{
	AqronosPoint minPt, maxPt;
	pcl::getMinMax3D (*pc, minPt, maxPt);

	double pc_length = maxPt.y - minPt.y;
	double out_width = ((params.VelWindow/200.0) * pc_length); // Divide by 2 * 100
	double min_y = minPt.y + out_width;
	double max_y = maxPt.y - out_width;

	// std::cout << "Min: " << min_y << "   max: " << max_y << " Length: " << pc_length << "  Before: " <<  idx.size() << std::endl;

	// Remove less than min, max and nan
	idx.erase(std::remove_if(idx.begin(), idx.end(), 
        [=](size_t i) {
        	return std::isnan(vel[i]) || (pc->points.at(i).y < min_y) || (pc->points.at(i).y > max_y);
        }), idx.end());

	// std::cout << "After: " << idx.size() << std::endl;
}

void LidarFrame::RemoveOutsideWindowFrame(std::vector<size_t> & idx, const std::vector<double> & vel, const std::shared_ptr<pcl::PointCloud<AqronosPoint>> pc)
{
	// Remove points outside velocity window
    int right = (int) roundf(((frame_cols * (params.VelWindow/2.0)) / 100.0) + (x_delay * frame_cols)) ;
	int left = (int) roundf(((frame_cols * (100 - (params.VelWindow/2.0))) / 100.0) + (x_delay * frame_cols)) ;
	if(params.VelWindow == 0)
	{
		/* Just remove nan.  Keep all points for velocity filtering */
		idx.erase(std::remove_if(idx.begin(), idx.end(), 
	        [=](size_t i) {
	        	return std::isnan(vel[i]);
	        }), idx.end());
	}
	else if( right > frame_cols != left > frame_cols )
	{
		if( right > left )
		{
			int temp = right;
			right = left;
			left = temp;
		}
		right %= (frame_cols+1);
		left %= (frame_cols+1);
		// Remove left and right and nan
		idx.erase(std::remove_if(idx.begin(), idx.end(), 
	        [=](size_t i) {
	        	return std::isnan(vel[i]) || ( (pc->points.at(i).w < right && pc->points.at(i).w > left));
	        }), idx.end());
	}
	else
	{
		if( right < left )
		{
			int temp = right;
			right = left;
			left = temp;
		}
		right %= (frame_cols+1);
		left %= (frame_cols+1);
		// Remove left and right and nan
		idx.erase(std::remove_if(idx.begin(), idx.end(), 
	        [=](size_t i) {
	        	return std::isnan(vel[i]) || ( ! (pc->points.at(i).w < right && pc->points.at(i).w > left));
	        }), idx.end());
	}
}
