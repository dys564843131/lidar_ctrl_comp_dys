#include "lidar_frame/filter2d.hpp"

Filter2d::Filter2d(ros::NodeHandle &n) :
    server{n}
{
	nh = &n;	

	f = boost::bind(&Filter2d::CFGCallback, this, _1, _2);
	server.setCallback(f);

	/* Initialize params and theta, then add callbacks */
	frame_sub = nh->subscribe("/udp_packet/udp_frame", 100, &Filter2d::Filter, this);
	frame_pub = nh->advertise<lidar_frame::frame>("/median_filter/filt_frame", 100);
}

void Filter2d::Filter(const lidar_frame::frame::ConstPtr& f)
{
    ros::Time filt_timer = ros::Time::now();
	ROS_INFO_STREAM_ONCE("Publishing 2d Filtered Frames..");

	lidar_frame::frame filt_frame;

    /* Copy data from input frame */
    /* Copy overhead to be reduced through nodelets */
	filt_frame.header = f->header;
	filt_frame.num_points = f->num_points;
	filt_frame.avg_intensity = f->avg_intensity;
	filt_frame.triggerA = f->triggerA;
    filt_frame.v0 = f->v0;
    filt_frame.frame_rows = f->frame_rows;
    filt_frame.frame_cols = f->frame_cols;

    /******* Median Filter *******/
	// if(params.median_window_size <= 1)
	// {
 //        /* No median Filter */
	// 	/* Copy Radius and velocity Directly */
	// 	filt_frame.radius = f->radius;
	// 	filt_frame.velocity = f->velocity;
	// }
	// else if(params.SlowMedianFilter )
	// {
 //        MedianFilterSlow(f->radius, filt_frame.radius);
 //        MedianFilterSlow(f->velocity, filt_frame.velocity);

	// }
	// else
	// {
	// 	MedianFilter(f->radius, filt_frame.radius);
 //        MedianFilter(f->velocity, filt_frame.velocity);
 //        // Median2d(f->radius, filt_frame.radius, filt_frame.frame_rows, filt_frame.frame_cols);
 //        // Median2d(f->velocity, filt_frame.velocity, filt_frame.frame_rows, filt_frame.frame_cols);
	// }

    /******* Median Filter *******/
    if(params.median_window_size <= 1)
    {
        /* No median Filter */
        /* Copy Radius and velocity Directly */
        filt_frame.radius = f->radius;
        filt_frame.velocity = f->velocity;
    }
    else
    {
        MedianFilter(f->radius, filt_frame.radius);
        MedianFilter(f->velocity, filt_frame.velocity);
    }
    
    // std::vector<double> temp;
    // MedianFilter(f->radius, temp);
    // for(int i=0; i<temp.size(); ++i)
    // {
    //     if(temp.at(i) != temp.at(i))
    //         continue;
    //     if(temp.at(i) != filt_frame.radius.at(i))
    //     {
    //         ROS_ERROR_STREAM(i << " slow: " << temp.at(i) << "   reg:  " << filt_frame.radius.at(i));
    //     }
    // }
    //while(true);

    /* Publish Frame */
	frame_pub.publish( filt_frame );
    ROS_INFO_STREAM_THROTTLE(2,"[2D Filter]:  Filter Processing Time: " << (ros::Time::now() - filt_timer).toSec());
}

void Filter2d::CFGCallback(lidar_frame::filter2dConfig &config, uint32_t level)
{
	params = config;
}


void Filter2d::MedianHelper(std::vector<double>& window, double left, double right)
{
	auto it = std::lower_bound(window.begin(), window.end(), right); // find the position of right element
	window.insert(it, right); // insert it in the sorted vector
	it = std::lower_bound(window.begin(), window.end(), left); // find the position of left element
	window.erase(it); // remove it from the sorted vector
}

void Filter2d::MedianFilter(const std::vector<double> &in, std::vector<double> &out)
{
    //params.median_window_size = 5;
	out.resize(in.size());

	std::vector<double> window;
    /* Build Window */
	for(int i=0; i<params.median_window_size; ++i)
	{
		if( std::isnan(in[i]) )
			continue;
		window.push_back(in[i]);
	}

    std::sort(window.begin(), window.end()); // O(klog(k))
    

    // std::cout << "Initial Sorted Window" << std::endl;
    // for(auto i : window)
    // {
    //     std::cout << i << " ";
    // }
    // std::cout << std::endl;

    for (int i = 0; i < in.size(); ++i) // O((n-k+1)log(k))
    {
        // std::cout << "i: " << i << "\t\t\tcur point: " << in[i]  << std::endl;
        // std::cout << "Window:   ";
        // for(auto k : window)
        // {
        //     std::cout << k <<  "  ";
        // }
        // std::cout << std::endl;


        /* Corner Case for window */
        // if( i < params.median_window_size || i >= (in.size() - params.median_window_size) )
        // {
        //     out[i] = in[i];
        //     continue;
        // }

    	/*  Empty Window or edge case begining of filter */
    	// if( window.size() == 0 )
    	// {
    	// 	out[i] = in[i];
    	// }
        

        // out[i] = in[i];
        

        // std::vector<double> window2;
        // /* Pre Window */
        // for(int prev_win=i; prev_win > (i - params.median_window_size); --prev_win)
        // {
        //     if( !std::isnan(in[prev_win]) )
        //     {
        //         window2.push_back(in[prev_win]);
        //     }
        // }
        //  Post Window 
        // for(int post_win=i+1; post_win <= (i + params.median_window_size); ++post_win)
        // {
        //     if( !std::isnan(in[post_win]) )
        //     {
        //         window2.push_back(in[post_win]);
        //     }
        // }
        // std::sort(window2.begin(), window2.end()); // O(klog(k))
        

    	
        /* Check bounds first */
    	if( i < (in.size() - params.median_window_size) && !std::isnan(in[i+params.median_window_size]) )
    	{
            // std::cout << "Adding: " << in[i+params.median_window_size] << std::endl;
            // std::cout << std::endl << std::endl << std::endl;
    		//MedianHelper(window, added.front(), in[i+params.median_window_size]);
            /* Add point to sorted window */
            if( window.size() != 0  )
            {
                auto it = std::lower_bound(window.begin(), window.end(), in[i+params.median_window_size]); // find the position of new element
                window.insert(it, in[i+params.median_window_size]); // insert it in the sorted vector
            }
            else
            {
                //ROS_ERROR_STREAM("HAHA");
                window.push_back(in[i+params.median_window_size]);
            }

            // auto it = std::lower_bound(window.begin(), window.end(), in[i+params.median_window_size]); // find the position of new element
            // window.insert(it, in[i+params.median_window_size]); // insert it in the sorted vector
            
            // added.push(in[i+params.median_window_size]); // Track order of added points

    		// added.pop();    		
    	}

        /* Remove oldest point from window every time */
        // if(window.size() != 0)
        // {
        //     auto it = std::lower_bound(window.begin(), window.end(), added.front());
        //     window.erase(it); // remove it from the sorted vector
        //     added.pop();
        // }
        if( (i >= params.median_window_size) && !std::isnan(in[i-params.median_window_size]) )
        {
            // std::cout << "Removing: " << in[i-params.median_window_size] << std::endl;
            // std::cout << std::endl << std::endl << std::endl;

            auto it = std::lower_bound(window.begin(), window.end(), in[i-params.median_window_size]);
            window.erase(it); // remove it from the sorted vector
        }


        if( (window.size() != 0)  && (i >= params.median_window_size) && (i < (in.size() - params.median_window_size)) )
        {
            int window_idx = floor(window.size()/2.0);
            out[i] = window.at(window_idx);
        }
        else
        {
            out[i] = in[i];
        }
        // std::cout << "Out: " << out[i] << std::endl;
        // std::cout << std::endl << std::endl;

        // for(int k=0; k<window2.size() && k < window2.size(); ++k)
        // {
        //     if( window2.at(k) != window.at(k) )
        //     {
        //         std::cout << "Window ORIG:   ";
        //         for(auto j : window)
        //         {
        //             std::cout << j <<  "  ";
        //         }
        //         std::cout << std::endl;
        //         std::cout << "Window2:   ";
        //         for(auto j : window2)
        //         {
        //             std::cout << j <<  "  ";
        //         }
        //         std::cout << std::endl;
        //         while(1);
        //     }
        // }
       
        
    }
}

void Filter2d::Median2d(const std::vector<double> &in, std::vector<double> &out, const int height, const int width)
{
    out.resize(height * width);
    double window_diff = 20;
    if(in.size() < height * width)
    {
        ROS_ERROR_STREAM("TODO");
    }
    for(int h = 0; h < height; ++h)
    {
        for(int w = 0; w < width; ++w)
        {
            int i = h*width + w;
            if( params.median_window_size == 0 )
            {
                out[i] = in[i];
                continue;
            }

            /* Build window */
            std::vector<double> window;

            /* Build Window for Wall */
            for(int w_h=std::max(0, h-params.median_window_size); w_h < std::min(height, h+params.median_window_size); ++w_h)
            {
                for(int w_w=std::max(0, w-params.median_window_size); w_w < std::min(width, w+params.median_window_size); ++w_w)
                {
                    int index = w_h*width + w_w;
                    if( !std::isnan( in[index] ) && abs( in[i] - in[index] ) < window_diff)
                    {
                        window.push_back( in[index] );
                    }
                }
            }

            if(window.size() == 0)
            {
                out[i] = in[i]; // nan
                continue;
            }

            std::sort(window.begin(), window.end()); // O(klog(k))
            out[i] = window[floor(window.size()/2.0)];
        }
    }
}


void Filter2d::MedianFilterSlow(const std::vector<double> &in, std::vector<double> &out)
{
	out.resize(in.size());
    for (int i = 0; i < in.size(); ++i) // O((n-k+1)log(k))
    {
    	/* Corner Case */
    	if(i < params.median_window_size || i >= (in.size() - params.median_window_size) || params.median_window_size == 0)
    	{
    		out[i] = in[i];
    		continue;
    	}

    	std::vector<double> window;

        /* Pre Window */
        for(int prev_win=i; prev_win > (i - params.median_window_size); --prev_win)
        {
            if( !std::isnan(in[prev_win]) )
            {
                window.push_back(in[prev_win]);
            }
        }

        /* Post Window */
        for(int post_win=i+1; post_win <= (i + params.median_window_size); ++post_win)
        {
            if( !std::isnan(in[post_win]) )
            {
                window.push_back(in[post_win]);
            }
        }

        if(window.size() == 0)
        {
            out[i] = in[i]; // nan
            continue;
        }

    	std::sort(window.begin(), window.end()); // O(klog(k))
    	out[i] = window[floor(window.size()/2.0)];
    }
}
