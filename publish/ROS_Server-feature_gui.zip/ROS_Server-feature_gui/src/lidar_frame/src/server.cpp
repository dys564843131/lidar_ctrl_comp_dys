#include <iostream>
#include <fstream>

#include "ros/ros.h"
#include "lidar_frame/packet_send.hpp"

#define BUFFERSIZE 1024 * 1024

// ifstream bigFile("mybigfile.dat");
// constexpr size_t bufferSize = 1024 * 1024;
// unique_ptr<char[]> buffer(new char[bufferSize]);
// while (bigFile)
// {
//     bigFile.read(buffer.get(), bufferSize);
//     // process data in buffer
// }

float ReadFloat32( char * d, int idx  )
{
	float f;
	char bytes[4];
	bytes[0] = d[idx]; bytes[1] = d[idx+1]; bytes[2] = d[idx+2]; bytes[3] = d[idx+3];
	memcpy(&f, bytes, sizeof(f));
	return f;
}

void UpdateParams(const ros::NodeHandle &n, int & frame_points, double & cloud_fps)
{
	int temp1, temp2;
	if( n.getParam("/frame_rows", temp1) && n.getParam("/frame_cols", temp2) )
	{
		if(frame_points != temp1 * temp2)
		{
			ROS_INFO_STREAM("[Packet Server]: Updated Frame Rows to: " << temp1);
			ROS_INFO_STREAM("[Packet Server]: Updated Frame Cols to: " << temp2);
		}
		frame_points = temp1 * temp2;		
	}

	double temp3;
	if( n.getParam("/cloud_fps", temp3) )
	{
		cloud_fps = temp3;
	}
}

int main(int argc, char * argv[])
{
	std::string host;
	int port;
	std::string filename;
	int frame_points = 50000;
	double cloud_fps = 10.0;
	int StartFrame = 0;

	/* Initialize ros node */
	ros::init(argc, argv, "udp_server");
	ros::NodeHandle n("~");

	//while(ros::ok());
	//return 0;

	/* Get Global Changing Params */
	UpdateParams(n, frame_points, cloud_fps);

	/* Get Command Line Arguments */
	n.param<int>("start_frame", StartFrame, 0);
	
	/* Get Host/port params */
	n.param<std::string>("host", host, "127.0.0.1");
	n.param<int>("port", port, 12345);

	ROS_INFO_STREAM("[Packet Server]: Start Frame: " << StartFrame);
	// std::cout << "cloudfps: " << cloud_fps << std::endl;
	// std::cout << "Frame Points: " << frame_points << std::endl;
	// std::cout << "Host: " << host << std::endl;
	// std::cout << "Port: " << port << std::endl;

	/* pt_frm is the segmentor of the .bin files.  
	 * Each .bin has pt_frm radius' then pt_frm velocities' 
	*/
	int pt_frm = 25000;
	if( frame_points == 24000 )
		pt_frm = 24000;

	/* Avoid Reading in entire file at once.  Buffer in bytes_per_section */
	int bytes_per_section = pt_frm * 2 * 4; // 4 bytes per float 
	
	/* Array of floating points read from .bin file */
	float results[pt_frm*2];
	
	/* Construct UDP thread */
	PacketSend packets(host, port);

	/* Calculate how long to sleep between pointclouds */
	// int sleep_time = (1000000.0 / ((double) cloud_fps ));
	// int point_count = -frame_points;

	if( n.getParam("file", filename) )
	{
		ROS_INFO_STREAM("[Packet Server]: Reading Pointcloud Data From: " << filename);

		std::ifstream ifs(filename, std::ios::binary);
		std::unique_ptr<char[]> file_data(new char[bytes_per_section]);

		ifs.read(file_data.get(), bytes_per_section);

		double frame_count; // Track the current frame

		int point_count = -2*frame_points; // Set to negative so we before a few pointclouds ahead
		ros::Time offset = ros::Time::now();
		while( ros::ok() )
		{

			while( ros::ok() && ifs )
			{
				int file_idx = 0;
				int i = 0;
				int bad_points = 0;
				//std::cout << "File Idx: " << file_idx << std::endl;
				if(frame_count >= StartFrame)
				{
					/* Read 25000 radius from file */
					for(; i < pt_frm; i++, file_idx+=4)
					{
						results[i] = ReadFloat32( file_data.get(), file_idx);
						if(results[i] == 0)
						{
							bad_points++;
						}
					}

					/* Read 25000 velocity from file */
					for(; i < pt_frm*2; i++, file_idx+=4)
					{
						results[i] = ReadFloat32( file_data.get(), file_idx);
					}				

					packets.SendUDP(results, 2*pt_frm, pt_frm);

					point_count += pt_frm;
					if( point_count >= ( frame_points * cloud_fps) )
					{
						point_count = 0;

						/* Get Global Changing Params */
						UpdateParams(n, frame_points, cloud_fps);

						/* Calculate how long we should sleep for */
						/* Offset with how much time it took to queue up packets */
						int time_diff = 1000000 - 1000000*(ros::Time::now() - offset).toSec();
						if(time_diff > 0)
						{
							// Sleep while ROS Timer callback display buffered PointClouds.
							usleep( time_diff ); 
						}
						else
						{
							ROS_WARN_STREAM("[Packet Server]: Cloud FPS TOO Fast");
						}
						offset = ros::Time::now();
					}

				}

				ifs.read(file_data.get(), bytes_per_section);
				frame_count += pt_frm / ((double) frame_points);
			}
			/* Reset to beggining of file */
			ifs.clear();                 // clear fail and eof bits
			ifs.seekg(0, std::ios::beg); // back to the start!

			/* Read in initial data */
			ifs.read(file_data.get(), bytes_per_section);

			frame_count = 0;
			packets.Reset();
			point_count = -2*frame_points;
			//ROS_ERROR_STREAM("RESETTING");
			ROS_INFO_STREAM("[Packet Server]: Reset Data Playback");
			//usleep(2000000);
		}

	} // .889
	else
	{
		std::cout << "Using Static Data" << std::endl;
		int const_data = 450;
		while( ros::ok() )
		{
			int i = 0;
			/* Read 25000 radius from file */
			for(; i < pt_frm ; i++)
			{
				results[i] = const_data;
			}

			/* Read 25000 velocity from file */
			for(; i < pt_frm*2 ; i++)
			{
				results[i] = 0;
			}

			/* Queue up data to send over UDP */
			packets.SendUDP(results, 2*pt_frm, pt_frm);

			//std::cout << "File pos: " << file_idx << "  End: " << pos << std::endl;
			//usleep(90000);
		}
	}

	while( ros::ok() )
	{
		/* Allow thread to keep sending queued udp packets */
		usleep(1000);
	}

	// std::cout << "DONE" << std::endl;
	return 0;

}
