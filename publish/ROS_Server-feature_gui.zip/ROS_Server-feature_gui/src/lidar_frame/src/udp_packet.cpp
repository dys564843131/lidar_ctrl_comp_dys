#include "lidar_frame/udp_packet.hpp"

UDPPacket::UDPPacket(std::string host, short port, ros::NodeHandle &nh)
	: socket_(io_service),
	sender_endpoint_(boost::asio::ip::address::from_string(host), port),
	server{nh}
{
	n = &nh;
	
	frame = NULL;
	/* Initializes dynamic params */
	f = boost::bind(&UDPPacket::CFGCallback, this, _1, _2);
	server.setCallback(f);

	FrameInit();

	frame_pub = n->advertise<lidar_frame::frame>(FRAME_PUB_ID, FRAME_BUFFER);
	
	socket_.open(udp::v4());
}


void UDPPacket::CFGCallback(const lidar_frame::udp_frameConfig &config, uint32_t level)
{
	params = config;
	if(params.frame_rows == 0)
		params.frame_rows = 40;
	if(params.frame_cols == 0)
		params.frame_cols = 1250;


	/* Set directly to frame */
	if(frame != NULL && frame->num_points == 0)
	{
		SetFrameParams();
	}

	if( params.IgnoreV0 )
	{
		v0_frame_count = 0;
		v0_found = false;
		v0.clear();
		v0_count.clear();		
	}

	UpdateGlobalParams();
}

void UDPPacket::UpdateGlobalParams()
{
	if(params.frame_cols != frame_cols_tracker)
	{
		frame_cols_tracker = params.frame_cols;
		n->setParam("/frame_cols", frame_cols_tracker);
	}

	if(params.frame_rows != frame_rows_tracker)
	{
		frame_rows_tracker = params.frame_rows;
		n->setParam("/frame_rows", frame_rows_tracker);
	}
}

void UDPPacket::SetFrameParams()
{
	// if(frame->frame_rows != params.frame_rows)
	// 	ROS_INFO_STREAM("[UDP Packet]:  Adjust Frame to have: " << params.frame_rows << " rows");
	// if(frame->frame_cols != params.frame_cols)
	// 	ROS_INFO_STREAM("[UDP Packet]:  Adjust Frame to have: " << params.frame_cols << " columns");
	if(NUM_TRIG_I != params.NumberTrigI)
		ROS_INFO_STREAM("[UDP Packet]:  Number of Trigger I per frame: " << params.NumberTrigI);
	if(UseTrigger != params.UseTriggers && UseTrigger)
		ROS_INFO_STREAM("[UDP Packet]:  Triggers Enabled!");
	if(OnlyTrigA != params.OnlyTrigA)
		ROS_INFO_STREAM("[UDP Packet]:  Only Using Trigger A");
	if(UseTrigB != params.UseTrigB && params.UseTrigB){
		ROS_WARN_STREAM("[UDP Packet]:  Trigger B Enabled!");
	}

	frame->frame_rows = params.frame_rows;
	frame->frame_cols = params.frame_cols;
	NUM_TRIG_I = params.NumberTrigI;
	UseTrigger = params.UseTriggers;
	OnlyTrigA = params.OnlyTrigA;
	UseTrigB = params.UseTrigB;

}

void UDPPacket::Receive()
{
	socket_.bind(sender_endpoint_);
	do_receive();
	io_service.run();
}

void UDPPacket::PublishFrame(std::shared_ptr<lidar_frame::frame> & f)
{
	if( ros::ok() )
	{		
		if( ! v0_found && ! params.IgnoreV0 ) 
		{
			UpdateV0( f );
		}
		if( v0_found && params.DumpV0 )
		{
			std::cout << "Writing to ~/.ros/v0.txt" << std::endl;
			std::ofstream v0_out;
			v0_out.open("v0.txt");
			for( int idx=0; idx<v0.size(); ++idx )
			{
				v0_out << v0[idx] / (( double ) v0_count[idx]) << std::endl;
			}
			v0_out.close();
		}

		/* Print extra frame info */
		ROS_INFO_STREAM_ONCE("[UDP Packet]:  Transmitting Frames...");
		ROS_INFO_STREAM_THROTTLE(2,"[UDP Packet]:  Frame Number: " << frame_counter);
		
		// ROS_INFO_STREAM("Publish Frame " << f->header.seq << " with: " << f->num_points << " Points");
		if( UseTrigB || UseTrigger	)
		{
			//f->frame_cols = floor( f->num_points / ((double) f->frame_rows) );
			// f->num_points = f->frame_cols * f->frame_rows;
			f->frame_rows = (f->triggerA.size() - 1);
		}


		// ROS_INFO_STREAM("Publish Frame " << f->header.seq << " with: " << f->num_points << " Points");

		if(f->num_points == 0)
		{
			ROS_ERROR_STREAM("[UDP Packet]:  Frame with Zero Points");
			return;
		}
		/* Publish Frame */
		frame_pub.publish( *f );

		frame_counter++;
	}
}


void UDPPacket::UpdateV0(const std::shared_ptr<lidar_frame::frame> & f)
{
	if( UseTrigger )
	{
		/* Use triger idx as starting point for V0.  Ignore first and last triggers.  Average v0 over several poly rotatiations */
		/* Ignore points before first trigger and after last trigger (not complete poly rotations) */
		for( int trig_idx = 0; trig_idx < (f->triggerA.size() - 1); ++trig_idx)
		{
			/* Loop through each trigger. Adding points to V0 */
			int v0_idx = 0; // idx into v0.  Resets for every trigger.
			for(int point = f->triggerA[trig_idx]; point < f->triggerA[trig_idx+1]; ++point, ++v0_idx )
			{
				if( ! std::isnan( f->velocity.at(point)) && ! std::isnan( f->radius.at(point) ) )
				{
					while( v0_idx >= v0_count.size() )
					{
						v0_count.push_back(0);
						v0.push_back(0.0);
					}

					v0_count[v0_idx]++;
					v0[v0_idx] += f->velocity.at(point);
				}
			}
		}
	}
	else
	{
		/* Average v0 accross each column */
		for(int row = 0; row < f->frame_rows; ++row)
		{
			for(int col = 0; col < f->frame_cols; ++col )
			{
				int idx = row*f->frame_cols + col;
				if( ! std::isnan( f->velocity.at(idx)) && ! std::isnan( f->radius.at(idx) ) )
				{
					while( col >= v0_count.size() )
					{
						v0_count.push_back(0);
						v0.push_back(0.0);
					}

					v0_count[col]++;
					v0[col] += f->velocity.at(idx);
				}
			}
		}
	}

	if( v0_frame_count >= params.V0Frames )
	{
		v0_found = true;
	}
	v0_frame_count++;
}

void UDPPacket::FrameInit()
{
	frame_counter = 0;
	// GetParams();
	FrameReset();
}

void UDPPacket::FrameReset()
{
	frame.reset(new lidar_frame::frame);
	SetFrameParams();

	int frame_total_points = frame->frame_rows * frame->frame_cols;
	// frame->radius.resize(frame_total_points);
	// frame->velocity.resize(frame_total_points);
	// frame->avg_intensity.resize(frame_total_points);
	frame->radius.reserve(frame_total_points);
	frame->velocity.reserve(frame_total_points);
	frame->avg_intensity.reserve(frame_total_points);

	frame->triggerA.push_back(0);
	triggerI_count = 0;
	frame->header.stamp = ros::Time::now();	
	frame->header.seq = frame_counter;
	
}

void UDPPacket::do_receive()
{
	socket_.async_receive_from(
		boost::asio::buffer(data),
		sender_endpoint_,
		boost::bind(&UDPPacket::packet_handler, this, boost::asio::placeholders::error, boost::asio::placeholders::bytes_transferred));
}

void UDPPacket::add_to_vector(const double & val, const int & idx, std::vector<double> & vec)
{
	if(vec.size() <= idx)
	{
		vec.push_back(val);
	}
	else
	{
		vec.at(idx) = val;
	}
}

void UDPPacket::add_to_vector(const uint32_t & val, const int & idx, std::vector<uint8_t> & vec)
{
	if(vec.size() <= idx)
	{
		vec.push_back(val);
	}
	else
	{
		vec.at(idx) = val;
	}
}


void UDPPacket::CheckUDPError(int frame_check)
{
	//frame_tracker &= 0x0FFFFFFFF; // same size as frame_check
	if( frame_check != frame_tracker )
	{
		ROS_ERROR_STREAM("[UDP Packet]: Dropped UDP packets.  Current tracker: " << frame_tracker << ".  Recieved frame offset: " << frame_check);
		//ROS_ERROR_STREAM("[UDP Packet]: Dropped UDP packets.  Missing: " << frame_check - frame_tracker << " Points");
		// frame->num_points = frame_check;
		if(frame_check < frame_tracker)
		{
			// Assume frame was reset.
			frame_tracker = frame_check;
			frame->num_points = frame_check % (frame->frame_cols * frame->frame_rows);
		}
		else
		{
			// Jump the frame counter forward. Push nan
			// ROS_ERROR_STREAM("NUM_POINTS BADD: " << frame->num_points << "  To: " << frame_check);
			int frame_catch = frame_check % (frame->frame_cols * frame->frame_rows);
			/* Add points above */
			while( frame_catch > frame->num_points )
			{
				add_to_vector(std::numeric_limits<float>::quiet_NaN(), frame->num_points, frame->radius);
				add_to_vector(std::numeric_limits<float>::quiet_NaN(), frame->num_points, frame->velocity);
				add_to_vector(0, frame->num_points, frame->avg_intensity);
				add_to_vector(0, frame->num_points, frame->v0);
				frame->num_points++;
			}
			/* Reset frame counter if below */
			frame->num_points = frame_catch;
			frame_tracker = frame_check;
		}
	}
}

void UDPPacket::DeserializeData(int udp_idx)
{
	AqronosPacket * packet = &(data[udp_idx]);

	if(packet->header.frame_counter % 2 == 1) // if frame_offset is odd
		packet->header.frame_counter--; // use zero-based indexing

	CheckUDPError( packet->header.frame_counter );

	for(int data_idx=0; (data_idx < POINTS_PER_UDP_PACKET); data_idx++) 
	{
		/* Add Trig A */
		if( frame->num_points != 0 && packet->data[data_idx].TrigA )
		{
			frame->triggerA.push_back(frame->num_points);
		}

		/* If using triggers and recieve signal I, increment */
		if( UseTrigger && packet->data[data_idx].TrigI )
		{
			triggerI_count++;
		}

		/*  If not using triggers,  increment when full frame is recived. */
		if( ! ( UseTrigger || UseTrigB ) && frame->num_points >= ((frame->frame_rows*frame->frame_cols)- 1))
		{
			triggerI_count = NUM_TRIG_I;
		}

		double radius = process_rad(packet->data[data_idx].radius, frame->num_points);
		double velocity = process_vel(packet->data[data_idx].velocity, frame->num_points);

		int v0_idx;
		if( UseTrigger )
		{
			v0_idx = frame->num_points - frame->triggerA.back();
		}
		else
		{
			v0_idx = frame->num_points % frame->frame_cols;
		}

		if( v0_found && v0_count[v0_idx] != 0 )
		{
			double v0_val = (v0[v0_idx] / ((double) v0_count[v0_idx]) );
			velocity -= v0_val;
			add_to_vector(v0_val, frame->num_points, frame->v0);
		}
		else
		{
			add_to_vector(std::numeric_limits<float>::quiet_NaN(), frame->num_points, frame->v0);
		}

		// if ( std::isnan(radius) || std::isnan(velocity) )
		// {
		// 	radius = std::numeric_limits<float>::quiet_NaN();
		// 	velocity = std::numeric_limits<float>::quiet_NaN();
		// }

		/* Add Average Intensity, radius, velocity */
		add_to_vector(packet->data[data_idx].avg_int, frame->num_points, frame->avg_intensity);
		add_to_vector(radius, frame->num_points, frame->radius);
		add_to_vector(velocity, frame->num_points, frame->velocity);

		frame->num_points++;
		frame_tracker++;


		if( triggerI_count >= NUM_TRIG_I || ( ( UseTrigB ) && packet->data[data_idx].TrigB ) )
		{
			//std::cout << "Frame Number of Points:  " << frame->num_points << std::endl;
			/* If no trig A then add it */
			if( frame->triggerA.back() != frame->num_points )
			{
				frame->triggerA.push_back( frame->num_points );
			}

			PublishFrame(frame);
			FrameReset();
		}
	}
}

void UDPPacket::packet_handler(const boost::system::error_code& err, std::size_t bytes_transfered)
{
	

	/* Process Data */
	if (!err &&  bytes_transfered> 0)
	{
		ROS_INFO_STREAM_ONCE("[UDP Packet]:  Recieving Packets...");
		//PrintRawData(4);
		if( bytes_transfered != sizeof(AqronosPacket) )
		{
			ROS_WARN_STREAM("[UDP Packet]:  Ignoring Invalid Packet size with bytes:  " <<  bytes_transfered);
		}
		else
		{
			/* Dump raw UDP data into file*/
			if(UDPNumPackets > 0 && packet_counter < UDPNumPackets)
			{
				SaveUDPToFile("udp_bytes.txt", bytes_transfered);
			}

			DeserializeData();
			//std::cout << "========= NEW UDP PACKET  " << frame->num_points << " =========" << std::endl;
			// PrintRawData(bytes_transfered);
		}
	}

	// Constantly query
	if(ros::ok())
	{
		do_receive();
	}
}


void UDPPacket::SaveUDPToFile(std::string file_name, int bytes_transfered)
{
	std::fstream bytes_out;
	bytes_out.open(file_name, std::fstream::app);
	for(int i=0; i<bytes_transfered; ++i)
	{
		bytes_out << std::setw(2) << std::setfill('0') << std::hex << ((unsigned char *) data)[i] << " ";
	}
	bytes_out << std::endl;
	bytes_out.close();
	packet_counter++;
}

double UDPPacket::process_rad(uint16_t r_in, int idx)
{
	double r = r_in;
	// r -= 100;

	if( params.MinRadiusRaw > 0 && r < params.MinRadiusRaw)
	{
		// ROS_INFO_STREAM_DELAYED_THROTTLE(0.001, "r: " << r);
		return std::numeric_limits<float>::quiet_NaN();
	}
	if( params.MaxRadiusRaw > 0 && r > params.MaxRadiusRaw)
	{
		return std::numeric_limits<float>::quiet_NaN();
	}
	
	//r = ((r - 50) * 4.2 ) / 100;
	//r = 0.05*r - 9;
	// r = 0.0628*r - 25;
	//r = 0.0628*r - 12;
	r = params.RadiusScale * r + params.RadiusOffset;
	if(r <= 0)
	{
		return std::numeric_limits<float>::quiet_NaN();
	}
	// r *= 3;
	// r = ((r + 100) * 4.2 ) / 100;
	return r;
}

double UDPPacket::process_vel(uint16_t v_in, int idx)
{
	double v = v_in;

	if( params.MinVelocityRaw > 0 && v < params.MinVelocityRaw ) // 1.0
	{
		return std::numeric_limits<float>::quiet_NaN();
	}
	if( params.MaxVelocityRaw > 0 &&  v > params.MaxVelocityRaw ) // 400
	{
		return std::numeric_limits<float>::quiet_NaN();
	}

	return v;
}

/* Print Functions */
void UDPPacket::PrintRawData(int length)
{
	std::cout << "TODO" << std::endl;
	/* Wrap function in RAII-style scope guard */
	/* Prevents hex formatting from effecting all output */
	// {
	// 	std::cout << "Bytes:  " << length << std::endl;
	// 	std::cout.setf( std::ios_base::hex, std::ios::basefield );
		
	// 	for(uint i=0; i<length; ++i)
	// 	{

	// 		std::cout << std::setw(2) << std::setfill('0') << static_cast<unsigned>( static_cast<unsigned char *>( &data[0] )[i] );
	// 		std::cout << " ";
	// 	}
	// 	std::cout.setf( std::ios_base::dec, std::ios::basefield );
	// 	std::cout << std::endl;
	// } 
}
