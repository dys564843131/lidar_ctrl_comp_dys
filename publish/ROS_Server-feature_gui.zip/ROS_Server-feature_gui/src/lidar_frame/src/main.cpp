#include <iostream>

#include "ros/ros.h"

#include <lidar_frame/lidar_frame.hpp>
#include "lidar_frame/pcl_filter.hpp"
#include <lidar_frame/filter2d.hpp>
#include "lidar_frame/udp_packet.hpp"



#include <thread>

void CallbackThread(UDPPacket * p)
{
	/* Run Recieve in separate thread */
	/* since boost asio isnt ROS managed */
	p->Receive();
}


int main(int argc, char ** argv)
{
	ros::init(argc, argv, "aqronos");

	// Declare namespace for each dynamic reconfigure node
	ros::NodeHandle n_filter2d("~/filter2d");
	ros::NodeHandle n_lidar_frame("~/pointcloud");
	ros::NodeHandle n_udp_frame("~/udp_frame");
	ros::NodeHandle n_pcl_filter("~/pcl_filter");

	/* Declare each node class */
	LidarFrame l( n_lidar_frame );

	Filter_PCL f_pcl( n_pcl_filter );

	Filter2d f2d( n_filter2d );

	/* Setup UDP Server */
	std::string host;
	int port;
	n_udp_frame.param<std::string>("/host", host, "127.0.0.1");
	n_udp_frame.param<int>("/port", port, 12345);
	ROS_INFO_STREAM("Starting UDP Server");
	ROS_INFO_STREAM("Listening for:  " << host << ":" << port);
	
	UDPPacket p(host, port, n_udp_frame);
	std::thread t(CallbackThread, &p);


	/* Use 8 core multithreading. TODO add as parameter */
	ros::MultiThreadedSpinner spinner(8);
	spinner.spin();

	t.join();
	return 0;
}
