#include <iostream>

#include "ros/ros.h"

#include <lidar_frame/lidar_frame.hpp>


int main(int argc, char ** argv)
{
	ros::init(argc, argv, "pointcloud");

	// Declare namespace for each dynamic reconfigure node
	ros::NodeHandle n_lidar_frame("~");

	LidarFrame l( n_lidar_frame );

	ros::spin();

	return 0;
}
