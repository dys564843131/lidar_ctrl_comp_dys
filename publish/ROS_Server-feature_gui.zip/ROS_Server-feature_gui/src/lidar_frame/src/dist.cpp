#include <ros/ros.h>

#include "lidar_frame/ring_list.hpp"

bool CheckCenter(geometry_msgs::Point & center, ros::NodeHandle * n)
{
	double temp;
	bool ret = false;
	n->param<double>("/ring_x_offset", temp, 0.0);
	ret = ret || (temp != center.x);
	if(ret)
	{
		center.x = temp;
	}
	n->param<double>("/ring_y_offset", temp, 0.0);
	ret = ret || (temp != center.y);
	if(ret)
	{
		center.y = temp;
	}
	n->param<double>("/ring_z_offset", temp, 0.0);
	ret = ret || (temp != center.z);
	if(ret)
	{
		center.z = temp;
	}
	return ret;
}

int main( int argc, char** argv )
{
	ros::init(argc, argv, "basic_shapes");
	ros::NodeHandle n;
	// ros::Publisher marker_pub = n.advertise<visualization_msgs::MarkerArray>("distance_rings", 1);

	geometry_msgs::Point center;

	

	RingList marker_list(&n, center, 90, 2);
	marker_list.AddTimer();
	while(ros::ok())
	{
		if( CheckCenter(center, &n) )
		{
			// std::cout << "Center1234: " << center << std::endl;
			marker_list.SetCenter(center);
		}
		ros::spinOnce();
	}
	ros::spin();


	return 0;
}