#include <iostream>

#include "ros/ros.h"

#include <lidar_frame/lidar_frame.hpp>

void PCCallback(const sensor_msgs::PointCloud2::ConstPtr& pc)
{
	std::cout << "+++++++Point CLoud+++++++++++++" << std::endl;
	std::cout << "Seq: " << pc->header.seq << std::endl;
	std::cout << "Height: " << pc->height << std::endl;
	std::cout << "Width: " << pc->width << std::endl;

	for(auto pf : pc->fields)
	{
		std::cout << pf.name << std::endl;
		std::cout << "	Offset: " << pf.offset << std::endl;
		std::cout << "	DT: " << pf.datatype << std::endl;
		std::cout << "	count: " << pf.count << std::endl;
	}

	std::cout << "Is big endian:  " << (pc->is_bigendian  ? "True" : "False") << std::endl;
	std::cout << "Point Step:  " << pc->point_step << std::endl;
	std::cout << "row step:  " << pc->row_step << std::endl;
	std::cout << "Is Dense:  " << (pc->is_dense ? "True" : "False") << std::endl;
		
	std::cout << std::endl;

	//pcl::PointCloud<AqronosPoint> pc2;
	pcl::PointCloud<pcl::PointXYZI> pc2;
	pcl::fromROSMsg(*pc, pc2);

	for(int i=0; i<pc2.size(); i+=1000)
	{
		std::cout << "Point " << i+1 << std::endl;
		//PrintPoint(pc2.at(i));
	}


}

int main(int argc, char ** argv)
{



	ros::init(argc, argv, "pc_sub");
	ros::NodeHandle n("");

	ros::Subscriber sub = n.subscribe("/lidar_frame/pointcloud", 10, &PCCallback);

	ros::spin();
	return 0;
}
