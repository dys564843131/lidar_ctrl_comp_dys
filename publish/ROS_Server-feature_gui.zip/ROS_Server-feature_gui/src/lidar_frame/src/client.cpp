#include <boost/asio.hpp>

#include "ros/ros.h"
#include <ros/console.h>
#include <thread>

#include "lidar_frame/udp_packet.hpp"


void CallbackThread()
{
	/* Thread for frame ROS Callbacks */
	/* The LidarFrame callback publishes the raw point cloud data from sensor */
	ros::spin();
}

int main(int argc, char ** argv)
{
	std::string host;
	int port;

	ros::init(argc, argv, "udp_frame");
	ros::NodeHandle n("~");

	n.param<std::string>("/host", host, "127.0.0.1");
	n.param<int>("/port", port, 12345);

	ROS_INFO_STREAM("Starting UDP Server");
	ROS_INFO_STREAM("Listening for:  " << host << ":" << port);
	
	UDPPacket p(host, port, n);
	std::thread t(CallbackThread);
	p.Receive();
	t.join();
	return 0;
}
