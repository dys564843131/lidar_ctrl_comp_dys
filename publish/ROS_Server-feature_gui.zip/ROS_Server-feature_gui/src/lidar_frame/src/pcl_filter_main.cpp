#include "ros/ros.h"

#include "lidar_frame/pcl_filter.hpp"


int main(int argc, char ** argv)
{
	ros::init(argc, argv, "pcl_filter");
	ros::NodeHandle n("~");

	Filter_PCL f_pcl( n );

	ros::spin();
	return 0;
}
