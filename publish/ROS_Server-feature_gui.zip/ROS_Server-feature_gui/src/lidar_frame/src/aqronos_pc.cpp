#include "lidar_frame/aqronos_pc.hpp"

AqronosPointCloud::AqronosPointCloud(ros::NodeHandle *n, pcl::PointCloud<AqronosPoint>::Ptr pc_in) : 
	_data{pc_in},
	bounding_box{new pcl::PointCloud<AqronosPoint>},
	keypoints{new pcl::PointCloud< pcl::PointWithScale >},
	n(n)
{
	_data->is_dense = false;
}


void AqronosPointCloud::VelColor()
{
	double vel_max, vel_min;
	MaxMinVel(vel_max, vel_min);
	// std::cout << "Max vel: " << vel_max << std::endl;
	// std::cout << "Min vel: " << vel_min << std::endl;

	// scale red between 0 and 255
	// scale blue oppostie
	double scale = (255)/(vel_max - vel_min);
	for(int i=0; i<size(); ++i)
	{
		double vel_col = scale * (_data->points.at(i).vel - vel_min);
		_data->points.at(i).r = vel_col;
		_data->points.at(i).b = 255 - vel_col;
		_data->points.at(i).g = 50;
	}
}

void AqronosPointCloud::MaxMinVel(double & ma, double & mi)
{
	ma = -100000000;
	mi = 100000000;
	for(auto p : *_data)
	{
		ma = std::max(ma, p.vel);
		mi = std::min(mi, p.vel);
	}
}

void AqronosPointCloud::Organize(int height, int width)
{
	// std::cout << "Setting Organized.  height: " <<  height << "   width:  " << width << "  Num points:  " << _data->size() << std::endl;
	_data->height = height;
	_data->width = width;
	_data->is_dense = false;
}

void AqronosPointCloud::push_back(const AqronosPoint &p)
{
	_data->push_back(p);
	vel.push_back(p.vel);
	vel_avg += p.vel;
	// rad.push_back(p.radius);
	if(p.radius > 0)
		rad.push_back(p.radius);
}

AqronosPoint AqronosPointCloud::at(int idx)
{
	return _data->at(idx);
}

size_t AqronosPointCloud::size()
{
	return _data->size();
}


void AqronosPointCloud::RemoveNaN()
{
	std::vector<int> ind;
	pcl::removeNaNFromPointCloud(*_data, *_data, ind);
}

void AqronosPointCloud::FilterTheta( const double theta, const bool KeepOrganized )
{
	/* Remove points with theta > max_theta */
	// ROS_ERROR_STREAM("Point Before: " << _data->points.size());
	pcl::ConditionalRemoval<AqronosPoint> condrem(false);
	pcl::ConditionAnd<AqronosPoint>::Ptr cond_out(new pcl::ConditionAnd<AqronosPoint> ());
	cond_out->addComparison (pcl::FieldComparison<AqronosPoint>::ConstPtr (new
		pcl::FieldComparison<AqronosPoint>("theta", pcl::ComparisonOps::LT, theta)));

    condrem.setInputCloud( _data );
	condrem.setCondition( cond_out );
	condrem.setKeepOrganized( KeepOrganized );
	condrem.filter( *_data );
	// ROS_ERROR_STREAM("Point After: " << _data->points.size());
}

int AqronosPointCloud::GetGroundCoeff(pcl::ModelCoefficients::Ptr coefficients, const double dist_thresh, const int method)
{
	if(size() == 0)
	{
		return 0;
	}
	int ret = 0;
	int itter = 0;
	do
	{
		pcl::PointIndices::Ptr inliers(new pcl::PointIndices);
		// coefficients->values.clear();
		// coefficients = pcl::ModelCoefficients::Ptr(new pcl::ModelCoefficients);

		 /* Minimum points to find ground plane */
	    if(_data->points.size() < 500)
	    {
	    	return 0;
	    }
		
		/* Remove Planes untill we get the ground plane */
		pcl::SACSegmentation<AqronosPoint> seg;
		seg.setOptimizeCoefficients(true);
		// seg.setEpsAngle(.5);
		// seg.setAxis(Eigen::Vector3f(0,0,1));
		seg.setDistanceThreshold(dist_thresh);
		// seg.setModelType(pcl::SACMODEL_NORMAL_PLANE);
		seg.setModelType(pcl::SACMODEL_PLANE);
		// seg.setNormalDistanceWeight(0.1);
		seg.setMaxIterations(1000);
		seg.setMethodType(method);
		seg.setInputCloud(_data);

		seg.segment(*inliers, *coefficients);
		ret = inliers->indices.size();

		/* If failed to find plane, return 0 */
		if(inliers->indices.size() == 0)
		{
			return 0;
		}

		/* Remove Points from _data. */
		// std::cout << "Points Found:  "  << inliers->indices.size() << "   Data point Before: " << _data->points.size() << std::endl;
		pcl::ExtractIndices<AqronosPoint> extractor;
	    extractor.setInputCloud(_data);
	    extractor.setIndices(inliers);
	    extractor.setNegative(true);
	    extractor.filter(*_data);

	   
		// ROS_WARN_STREAM(itter << "  Points Left:  " << _data->points.size());
		itter++;
		/* Repeat while plane is not aligned with z-axis */
	} while( abs(coefficients->values[2]) < (abs(coefficients->values[1]) + abs(coefficients->values[0])));


	return ret;
}


int AqronosPointCloud::GroundFilter(const pcl::ModelCoefficients::Ptr coefficients, const double dist_thresh, const bool ColorGround)
{
	/* Model plane using current coefficients */
	if(coefficients->values.size() != 4 || size() == 0)
	{
		// ROS_ERROR_STREAM("No Ground Coefificients");
		return 0;
	}
	pcl::PointIndices::Ptr inliers(new pcl::PointIndices);
	pcl::SampleConsensusModelPlane<AqronosPoint>::Ptr dit(new pcl::SampleConsensusModelPlane<AqronosPoint>(_data)); 
	Eigen::Vector4f co = Eigen::Vector4f(coefficients->values[0], coefficients->values[1], 
										coefficients->values[2], coefficients->values[3]); 
	dit->selectWithinDistance(co, dist_thresh, inliers->indices);

	if(inliers->indices.size() == 0)
	{
		return 0;
	}

	if(ColorGround)
	{
		ground_vel_avg = 0.0;
		size_t inliers_size = 0;
		for(auto i : (inliers->indices))
		{
			if( std::isnan(_data->points.at(i).vel) || std::isnan(_data->points.at(i).radius) )
			{
				continue;
			}
			_data->points.at(i).r = 255;
			_data->points.at(i).g = 255;
			_data->points.at(i).b = 0;
			ground_vel_max = std::max(ground_vel_max, _data->points.at(i).vel);
			ground_vel_min = std::min(ground_vel_min, _data->points.at(i).vel);
			ground_vel_avg += _data->points.at(i).vel;
			inliers_size++;
		}

		ground_vel_avg /= ((double) inliers_size);
		for(int i=0; i<_data->points.size(); ++i)
		{
			_data->points.at(i).vel -= ground_vel_avg;
		}
		//ROS_INFO_STREAM_THROTTLE(1, "Ground Filtering Points: " << inliers->indices.size() << "\tGround Vel Max: " << ground_vel_max << "\tGround Vel Min: " << ground_vel_min << "\tGround Vel Avg: " << ground_vel_avg);
		// ROS_ERROR_STREAM("Ground Filtering Points: " << inliers->indices.size() << "\tGround Vel Max: " << ground_vel_max << "\tGround Vel Min: " << ground_vel_min << "\tGround Vel Avg: " << ground_vel_avg);
	}	
	
	return inliers->indices.size();
}


void AqronosPointCloud::NewGroundFilter( double max_theta, pcl::ModelCoefficients::Ptr coefficients, bool FindCoefficients)
{
	ros::Time tt = ros::Time::now();
	float distance_thresh = 0.15;
	pcl::PointCloud<AqronosPoint>::Ptr ground_points(new pcl::PointCloud<AqronosPoint>);

	// /* Remove NaN From Point cloud */
	// 
	// pcl::removeNaNFromPointCloud(*_data, *ground_points, ind);

	// pcl::removeNaNFromPointCloud(*_data, *temp, ind);
	// std::cout << "Before:  " << temp->size() << std::endl;

	

	// pcl::removeNaNFromPointCloud(*_data, *_data, ind);
	// std::cout << "After:  " << temp->size() << std::endl;

	/* Get Normals */
	// pcl::PointCloud<pcl::PointNormal>::Ptr point_normals(new pcl::PointCloud<pcl::PointNormal>);
	// pcl::NormalEstimation<AqronosPoint, pcl::PointNormal> ne;
	// //pcl::PointCloud<pcl::PointNormal>::Ptr out(new pcl::PointCloud<pcl::PointNormal>);
	// pcl::search::KdTree<AqronosPoint>::Ptr tree_n(new pcl::search::KdTree<AqronosPoint>());
	// ne.setInputCloud(_data);
	// ne.setSearchMethod(tree_n);
	// ne.setRadiusSearch(0.2);
	// ne.compute(*point_normals);


	/* Fit remaining points with PCL Segmentation */
	pcl::PointIndices::Ptr inliers(new pcl::PointIndices);
	if( FindCoefficients || coefficients->values.size() < 4 )
	{
		ROS_ERROR_STREAM("Finding Ground Coefificients");
		/* Use SAC Segmentation and RANSAC to find coeficents for plane model */
		pcl::SACSegmentation<AqronosPoint> seg;
		// pcl::SACSegmentationFromNormals<AqronosPoint, pcl::PointNormal> seg;
		/* Set Coefificients */
		// coefficients->values[0] = 0; // x
		// coefficients->values[1] = 0; // y
		// coefficients->values[2] = 1; // z
		seg.setOptimizeCoefficients(true);
		// seg.setEpsAngle(.5);
		// seg.setAxis(Eigen::Vector3f(0,0,1));
		seg.setDistanceThreshold(distance_thresh);
		// seg.setModelType(pcl::SACMODEL_NORMAL_PLANE);
		seg.setModelType(pcl::SACMODEL_PLANE);
		// seg.setNormalDistanceWeight(0.1);
		seg.setMaxIterations(10000);
		seg.setMethodType(pcl::SAC_RANSAC);
		seg.setInputCloud(ground_points);
		// seg.setInputNormals(point_normals);
		// std::cout << "here" << std::endl;
		seg.segment(*inliers, *coefficients);
	}
	else
	{
		/* Model plane using current coefficients */
		pcl::SampleConsensusModelPlane<AqronosPoint>::Ptr dit(new pcl::SampleConsensusModelPlane<AqronosPoint>(ground_points)); 
		// dit->setInputCloud(ground_points);
		Eigen::Vector4f co = Eigen::Vector4f(coefficients->values[0], coefficients->values[1], 
											coefficients->values[2], coefficients->values[3]); 
		dit->selectWithinDistance(co, distance_thresh, inliers->indices);
	}
	
	// std::cout << "after" << std::endl;

	/* Color Ground Points */
	/* Check if we found a plane and the plane is aligned to z axis */
	if (inliers->indices.empty() || abs(coefficients->values[2]) < (abs(coefficients->values[1]) + abs(coefficients->values[0])))
	{
		// ROS_ERROR_STREAM("Could not found any inliers.");
		return;
	}
	else
	{
		for(auto i : (inliers->indices))
		{
			_data->points.at(i).r = 255;
			_data->points.at(i).g = 0;
			_data->points.at(i).b = 255;
		}
	}

	
	// ROS_ERROR_STREAM("Ground Filte time: " << ros::Time::now() - tt  << "  Num points:  " << inliers->indices.size());
    // pcl::ExtractIndices<AqronosPoint> extractor;
    // extractor.setInputCloud(_data);
    // extractor.setIndices(inliers);
    // extractor.setNegative(true);
    // extractor.filter(*_data);
}


void AqronosPointCloud::DrawBoundingBox(pcl::PointXYZ orig, double length, double width, double height)
{

	ROS_WARN_STREAM("NOT HERE");
	return;
	// ROS_ERROR_STREAM("Box Start: (" << orig.x << "," << orig.y << "," << orig.z << ")");
	// ROS_ERROR_STREAM("Length: " << length << "  width: " << width << "  height: " << height);

	/* Length: Positive x from point */
	/* Width: Positive y from point */
	/* Height: Positive z */
	for(double i=0.0; i < length; i+=POINTS_PER_DIST)
	{
		AqronosPoint p0(orig.x + i, orig.y, orig.z, 0, 255, 0);
		AqronosPoint p1(orig.x + i, orig.y + width, orig.z, 0, 255, 0);
		AqronosPoint p2(orig.x + i, orig.y, orig.z + height, 0, 255, 0);
		AqronosPoint p3(orig.x + i, orig.y + width, orig.z + height, 0, 255, 0);
		bounding_box->points.push_back(p0);
		bounding_box->points.push_back(p1);
		bounding_box->points.push_back(p2);
		bounding_box->points.push_back(p3);
	}
	for(double i=0.0; i < width; i+=POINTS_PER_DIST)
	{
		AqronosPoint p0(orig.x, orig.y + i, orig.z, 0, 255, 0);
		AqronosPoint p1(orig.x + length, orig.y + i, orig.z, 0, 255, 0);
		AqronosPoint p2(orig.x, orig.y + i, orig.z + height, 0, 255, 0);
		AqronosPoint p3(orig.x + length, orig.y + i, orig.z + height, 0, 255, 0);
		bounding_box->points.push_back(p0);
		bounding_box->points.push_back(p1);
		bounding_box->points.push_back(p2);
		bounding_box->points.push_back(p3);
	}
	for(double i=0.0; i < height; i+=POINTS_PER_DIST)
	{
		AqronosPoint p0(orig.x, orig.y, orig.z + i, 0, 255, 0);
		AqronosPoint p1(orig.x + length, orig.y, orig.z + i, 0, 255, 0);
		AqronosPoint p2(orig.x, orig.y + width, orig.z + i, 0, 255, 0);
		AqronosPoint p3(orig.x + length, orig.y + width, orig.z + i, 0, 255, 0);
		bounding_box->points.push_back(p0);
		bounding_box->points.push_back(p1);
		bounding_box->points.push_back(p2);
		bounding_box->points.push_back(p3);
	}	
}

void AqronosPointCloud::Interpolate(int height, int width, double thresh)
{
	// int count = 0;
	for(int h=0; h<(height-1); h++)
	{
		for(int w=0; w<width; w++)
		{
			int i1 = w + width*h;
			int i2 = w + width*(h+1);
			if(i1 >= _data->points.size() || i2 >= _data->points.size())
			{
				break;
			}

			if(std::isnan(_data->points.at(i1).radius) || 
				std::isnan(_data->points.at(i1).vel) ||
				std::isnan(_data->points.at(i2).radius) || 
				std::isnan(_data->points.at(i2).vel))
			{
				continue;
			}

			double r;
			if(abs(_data->points.at(i1).radius - _data->points.at(i2).radius) >= thresh)
			{
				/* Dont average points when the radius difference too far apart */
				/* Dont add points instead of using same radius */
				continue;
				// r = _data->points.at(i1).radius;
			}
			else
			{
				r = (_data->points.at(i1).radius + _data->points.at(i2).radius)/2.0;
				// count++;
			}

			double th = (_data->points.at(i1).theta + _data->points.at(i2).theta)/2.0;
			double ph = (_data->points.at(i1).phi + _data->points.at(i2).phi)/2.0;

			AqronosPoint p;
			p.x =  r * cos(th) * cos(ph);
			p.y =  r * cos(th) * sin(ph);
			p.z =  r * sin(th);

			p.vel = (_data->points.at(i1).vel + _data->points.at(i2).vel)/2.0;
			p.radius = r;
			int shade = (_data->points.at(i1).r + _data->points.at(i2).r)/2.0;
			p.r = shade;
			p.b = shade;
			p.g = shade;

			p.h = h;
			p.w = w;
			p.point_moving = std::max(_data->points.at(i1).point_moving, _data->points.at(i2).point_moving);
			p.point_in_vel_window = _data->points.at(i1).point_in_vel_window || _data->points.at(i2).point_in_vel_window;
			p.v0 = (_data->points.at(i1).v0 + _data->points.at(i2).v0) / 2.0;

			_data->push_back(p);
		}
	}
	// ROS_ERROR_STREAM("Count: " << count);
}


void AqronosPointCloud::BuildMsg(std::string frame_id)
{
	
	// if(bounding_box->points.size() != 0)
	// {
	// 	std::cout << "bounding box size: " << bounding_box->points.size() << std::endl;
	// 	std::cout << "Data size: " << _data->points.size() << std::endl;
	// }

	/* Commited Print statements for debuggin PCL Library Issue */
	//*_data += *bounding_box; // Broken PCL Library

	// for(auto p : *bounding_box)
	// {
	// 	_data->push_back(p);
	// }

	// if(bounding_box->points.size() != 0)
	// {
	// 	std::cout << "Together size: " << _data->points.size() << std::endl;
	// 	std::cout << "Height: " << _data->height << "  width:  " << _data->width << std::endl;
	// }
	
	// if(_data->points.size() != _data->height * _data->width)
	// {
	// 	ROS_ERROR_STREAM("This is gunna break");
	// 	// while(true);
	// }
	pcl::toROSMsg(*_data, msg);
	pcl::toROSMsg(*bounding_box, box_msg);
	pcl::toROSMsg(*keypoints, keypoint_msg);

	header.frame_id = frame_id;
	msg.header = header;
	box_msg.header = header;
	keypoint_msg.header = header;
}

void AqronosPointCloud::PCLRadOultiers(const pcl::PointCloud< AqronosPoint >::Ptr &in, 
						pcl::PointCloud< AqronosPoint >::Ptr &out,
						const int filt_setMinNeighborsInRadius, const double filt_setRadiusSearch)
{
	std::vector<int> ind;
	// std::cout << "IN size: " << in->size() << std::endl;
	pcl::removeNaNFromPointCloud(*in, *out, ind);
	// std::cout << "OUT size: " << out->size() << std::endl;
	// std::cout << "Indicies size: " << ind.size() << std::endl;
	pcl::RadiusOutlierRemoval<AqronosPoint> outrem;
	outrem.setInputCloud(out);
	outrem.setRadiusSearch(filt_setRadiusSearch);
	outrem.setMinNeighborsInRadius(filt_setMinNeighborsInRadius);
	outrem.filter(*out);
}

void AqronosPointCloud::PCLStatOultiers(const pcl::PointCloud< AqronosPoint >::Ptr &in, 
						pcl::PointCloud< AqronosPoint >::Ptr &out,
						const int MeanK, const double StddevMulThresh)
{
	pcl::StatisticalOutlierRemoval<AqronosPoint> sor;
	sor.setInputCloud(in);
	sor.setMeanK(MeanK);
	sor.setStddevMulThresh(StddevMulThresh);
	sor.filter(*out);
}

void AqronosPointCloud::PCLMedian(const pcl::PointCloud< AqronosPoint >::Ptr &in, 
						pcl::PointCloud< AqronosPoint >::Ptr &out,
						const int WindowSize)
{
	pcl::MedianFilter<AqronosPoint> m;
	m.setInputCloud(in);
	m.setWindowSize(WindowSize);
	m.filter(*out);

	// pcl::FastBilateralFilter<AqronosPoint> fbFilter; 
 //    fbFilter.setInputCloud(in); 
 //    fbFilter.setSigmaR(1.0);
 //    fbFilter.setSigmaS(0.2);
 //    fbFilter.applyFilter(*out); 
}

void AqronosPointCloud::PointsNormal(const pcl::PointCloud< AqronosPoint >::Ptr &in, 
						pcl::PointCloud< pcl::PointNormal >::Ptr &out)
{
	pcl::NormalEstimation<AqronosPoint, pcl::PointNormal> ne;
	//pcl::PointCloud<pcl::PointNormal>::Ptr out(new pcl::PointCloud<pcl::PointNormal>);
	// std::cout << "Building tree" << std::endl;
	pcl::search::KdTree<AqronosPoint>::Ptr tree_n(new pcl::search::KdTree<AqronosPoint>());
	// std::cout << "Geting Normals" << std::endl;
	ne.setInputCloud(in);
	ne.setSearchMethod(tree_n);
	ne.setRadiusSearch(0.2);
	ne.compute(*out);
	
	// Copy the xyz info from cloud_xyz and add it to cloud_normals as the xyz field in PointNormals estimation is zero
	for(size_t i = 0; i<out->points.size(); ++i)
	{
		out->points[i].x = in->points[i].x;
		out->points[i].y = in->points[i].y;
		out->points[i].z = in->points[i].z;
	}
}

void AqronosPointCloud::PointsSIFT(const pcl::PointCloud< AqronosPoint >::Ptr &in, 
						pcl::PointCloud< pcl::PointWithScale >::Ptr &out)
{
	//pcl::PointCloud<pcl::PointWithScale> result;
	const float min_scale = 0.1f;
	const int n_octaves = 3;
	const int n_scales_per_octave = 4;
	const float min_contrast = 0.01f;
	// std::cout << "FINDING POINT NORMAL" << std::endl;
	pcl::PointCloud<pcl::PointNormal>::Ptr cloud_normals(new pcl::PointCloud<pcl::PointNormal>);
	PointsNormal(in, cloud_normals);

	// std::cout << "FINDING KEYPOINTS" << std::endl;
	// Estimate the sift interest points using normals values from xyz as the Intensity variants
	pcl::SIFTKeypoint<pcl::PointNormal, pcl::PointWithScale> sift;
	pcl::search::KdTree<pcl::PointNormal>::Ptr tree(new pcl::search::KdTree<pcl::PointNormal> ());
	sift.setSearchMethod(tree);
	sift.setScales(min_scale, n_octaves, n_scales_per_octave);
	sift.setMinimumContrast(min_contrast);
	sift.setInputCloud(cloud_normals);
	sift.compute(*out);
}

void AqronosPointCloud::GetKeypoints()
{
	RemoveNaN();
	if(_data->size() < 1000)
		return;

	// ROS_ERROR_STREAM("Data Size: " << _data->size());
	
	PointsSIFT(_data, keypoints);
	// ROS_ERROR_STREAM(std::endl << "Keypoint size: " << keypoints->size());
}

void AqronosPointCloud::Cluster( double cluster_dist )
{
	RemoveNaN();
	if(_data->size() < 1000)
		return;

	// pcl::PointCloud<AqronosPoint>::Ptr temppc(new pcl::PointCloud<AqronosPoint>);
	// float ma = -10000;
	// float mi = 100000;
	// double a = 0;
	// for(int i=0; i<_data->size(); ++i)
	// {
	// 	AqronosPoint p;
	// 	p.x = _data->at(i).vel / 10.0;
	// 	p.y = 0;
	// 	p.z = 0;
	// 	a += p.x;
	// 	ma = std::max(p.x, ma);
	// 	mi = std::min(p.y, mi);
	// 	temppc->push_back(p);
	// }
	// ROS_WARN_STREAM("Min:  " << mi << "   Max:  " << ma << "   Avg:  " << a/_data->size() );

	pcl::search::KdTree< AqronosPoint >::Ptr tree (new pcl::search::KdTree< AqronosPoint >);
	// tree->setInputCloud(_data);

	std::vector<pcl::PointIndices> cluster_indices;
	pcl::EuclideanClusterExtraction< AqronosPoint > ec;
	ec.setClusterTolerance(cluster_dist); // m
	ec.setMinClusterSize(100);
	ec.setMaxClusterSize(50000);
	ec.setSearchMethod(tree);
	ec.setInputCloud(_data);
	ec.extract(cluster_indices);

	int i=0;
	ROS_WARN_STREAM("Clusters: " << cluster_indices.size());
	for(std::vector<pcl::PointIndices>::const_iterator it = cluster_indices.begin (); it != cluster_indices.end (); ++it, ++i)
	{
		// if(i == 0)
		// {
		// 	continue;
		// }
		// ROS_WARN_STREAM("Cluster: " << i << "  points: " << it->indices.size());
		for(std::vector<int>::const_iterator pit = it->indices.begin(); pit != it->indices.end(); ++pit)
		{
			// _data->points.at(*pit).x = _data->points.at(*pit).radius * cos(_data->points.at(*pit).theta) * cos(_data->points.at(*pit).phi);
			// _data->points.at(*pit).y = _data->points.at(*pit).radius * cos(_data->points.at(*pit).theta) * sin(_data->points.at(*pit).phi);
			// _data->points.at(*pit).z = _data->points.at(*pit).radius * sin(_data->points.at(*pit).theta) ;
			// p.x = ((double) rad_arr[i]) * cos(cur_theta) * cos(cur_phi);
			// p.y = ((double) rad_arr[i]) * cos(cur_theta) * sin(cur_phi);
			// p.z = ((double) rad_arr[i]) * sin(cur_theta);
			if(i == 0)
			{
				_data->points.at(*pit).r = 255;
				_data->points.at(*pit).g = 255;
				_data->points.at(*pit).b = 255;
			}
			else if(i % 6 == 0)
			{
				_data->points.at(*pit).r = 255;
				_data->points.at(*pit).g = 0;
				_data->points.at(*pit).b = 0;
			}
			else if(i % 6 == 1)
			{
				_data->points.at(*pit).r = 255;
				_data->points.at(*pit).g = 255;
				_data->points.at(*pit).b = 0;
			}
			else if(i % 6 == 2)
			{
				_data->points.at(*pit).r = 255;
				_data->points.at(*pit).g = 0;
				_data->points.at(*pit).b = 255;
			}
			else if(i % 6 == 3)
			{
				_data->points.at(*pit).r = 0;
				_data->points.at(*pit).g = 255;
				_data->points.at(*pit).b = 0;
			}
			else if(i % 6 == 4)
			{
				_data->points.at(*pit).r = 0;
				_data->points.at(*pit).g = 255;
				_data->points.at(*pit).b = 255;
			}
			else if(i % 6 == 5)
			{
				_data->points.at(*pit).r = 0;
				_data->points.at(*pit).g = 0;
				_data->points.at(*pit).b = 255;
			}
		}
	}
}

void AqronosPointCloud::FilterVelWithGround(const double max_dist, const int min_points, const double MinVel, const double MaxVel, const double vel_perc_focus, const double cur_x_delay, const int width)
{
	//ROS_ERROR_STREAM("Max Ground: " << ground_vel_max << "   Min Ground:  " << ground_vel_min);
	FilterVel(max_dist, min_points, MinVel, MaxVel, vel_perc_focus, cur_x_delay, width);
}


int AqronosPointCloud::FilterVel(const double max_dist, const int min_points, const double vel_perc_focus, const double cur_x_delay, const int width)
{	
	if(size() == 0)
	{
		return 0;
	}
	int right = (int) roundf(((width * (vel_perc_focus/2.0)) / 100.0) + (cur_x_delay * width));
	int left = (int) roundf(((width * (100 - (vel_perc_focus/2.0))) / 100.0) + (cur_x_delay * width));
	int point_counter = 0;
	int points_checked = 0;
	for(int i=0; i<_data->points.size(); ++i)
	{
		/* Remove edges from Velocity Coloring */
		if( right > width != left > width )
		{
			if( _data->points.at(i).w < ((right > left) ? left : right) % (width+1) && _data->points.at(i).w > ((right < left) ? left : right) % (width+1))
				continue;
		}
		else
		{
			// ROS_ERROR_STREAM("Left: " << ((right < left) ? left : right) << "   Right:  " << ((right > left) ? left : right) );
			if( ! (_data->points.at(i).w < ((right < left) ? left : right) % (width+1) && _data->points.at(i).w > ((right > left) ? left : right) % (width+1)) )
				continue;
		}

		if( std::isnan(_data->points.at(i).radius) )
		{
			continue;
		}

		points_checked++;

		if( std::isnan(_data->points.at(i).vel) || ! _data->points.at(i).point_moving )
		{
			continue;
		}

		point_counter++;

		
		/* Scale max_dist between a = 1 and b = 3 with equation:
		 * f(x) = ((b - a)*(x - min)) / (max - min) + a
		 */
		// double cur_max_dist = (max_dist * (((2) * (_data->points.at(i).radius - min_r) / (max_r - min_r)) + 1));
		// double cur_max_dist = _data->points.at(i).radius;
		// double cur_max_dist = max_dist;
		bool bin_found = false;
		for(int j=0; j<vel_bins_init.size(); ++j)
		{
			//if( vel_bins_init.at(j).MinDist(_data->points.at(i)) < cur_max_dist )
			if( vel_bins_init.at(j).CheckMinDist(max_dist, i) )
			{
				bin_found = true;
				vel_bins_init.at(j).push_back(i);
				break;
			}
		}

		if( ! bin_found )
		{
			/* Create new bin */
			vel_bins_init.push_back(Bin(_data));
			/* And add point */
			vel_bins_init.back().push_back(i);
		}
	}
	ROS_INFO_STREAM_THROTTLE(1, "Points Moving: " << point_counter << "/" << points_checked);
	
	if( vel_bins_init.empty() )
		return 0;

	for(auto bin : vel_bins_init) // Should be vel_bins
	{
		if( bin.size() <= min_points )
			continue;

		// ROS_ERROR_STREAM("NUM POINTS:  " << bin.size() << "   Avg Dist:  " << bin.GetAvgDist());
		// ROS_INFO_STREAM("START BOX SIZE:  " << bounding_box->points.size());
		for(int i=0; i<bin.size(); ++i)
		{
			_data->points.at( bin.at(i) ).r = 255;
			_data->points.at( bin.at(i) ).b = 0;
			_data->points.at( bin.at(i) ).g = 0;
		}
		bin.GetBoundingBox(bounding_box);
		// ROS_WARN_STREAM("DONE:  " << bounding_box->points.size());
	}
	return point_counter;
}

void AqronosPointCloud::ColorVel(const double max_dist, const int min_points)
{
	if(size() == 0)
	{
		return;
	}
	int point_counter = 0;
	int points_checked = 0;
	// ROS_INFO_STREAM("Start COLOR");
	for(int i=0; i<_data->points.size(); ++i)
	{
		points_checked++;

		if( std::isnan(_data->points.at(i).vel) || ! _data->points.at(i).point_moving )
		{
			continue;
		}

		point_counter++;

		
		/* Scale max_dist between a = 1 and b = 3 with equation:
		 * f(x) = ((b - a)*(x - min)) / (max - min) + a
		 */
		// double cur_max_dist = (max_dist * (((2) * (_data->points.at(i).radius - min_r) / (max_r - min_r)) + 1));
		// double cur_max_dist = _data->points.at(i).radius;
		// double cur_max_dist = max_dist;
		bool bin_found = false;
		for(int j=0; j<vel_bins_init.size(); ++j)
		{
			//if( vel_bins_init.at(j).MinDist(_data->points.at(i)) < cur_max_dist )
			if( vel_bins_init.at(j).CheckMinDist(max_dist, i) )
			{
				bin_found = true;
				vel_bins_init.at(j).push_back(i);
				break;
			}
		}

		if( ! bin_found )
		{
			/* Create new bin */
			vel_bins_init.push_back(Bin(_data));
			/* And add point */
			vel_bins_init.back().push_back(i);
		}
	}
	// ROS_INFO_STREAM("[PCL Fliter]:  Points Moving: " << point_counter << "/" << points_checked);
	ROS_INFO_STREAM_THROTTLE(1, "[PCL Fliter]:  Points Moving: " << point_counter << "/" << points_checked);
	
	if( vel_bins_init.empty() )
		return;

	for(auto bin : vel_bins_init) // Should be vel_bins
	{
		if( bin.size() <= min_points )
			continue;

		// ROS_WARN_STREAM("NUM POINTS:  " << bin.size() << "   Avg Dist:  " << bin.GetAvgDist());
		// ROS_INFO_STREAM("START BOX SIZE:  " << bounding_box->points.size());
		for(int i=0; i<bin.size(); ++i)
		{
			_data->points.at( bin.at(i) ).r = 255;
			_data->points.at( bin.at(i) ).b = 0;
			_data->points.at( bin.at(i) ).g = 0;
		}
		bin.GetBoundingBox(bounding_box);
	// 	ROS_WARN_STREAM("DONE:  " << bounding_box->points.size());
	}
}

int AqronosPointCloud::FilterVel(const double max_dist, const int min_points, const double MinVel, const double MaxVel, const double vel_perc_focus, const double cur_x_delay, const int width)
{	
	if(size() == 0)
	{
		return 0;
	}
	// std::vector< std::vector<int> > vel_idxs;
	// std::vector< pcl::PointXYZ > centroids;


	//std::cout << "Average Velocity: " << vel_avg / ((double) vel.size()) << std::endl;

	// double max_r = *std::max_element(rad.begin(), rad.end());
	// double min_r = *std::min_element(rad.begin(), rad.end());


	// double max_v = *std::max_element(vel.begin(), vel.end());
	// double min_v = *std::min_element(vel.begin(), vel.end());

	

	//double vel_avg_calc = vel_avg / ((double) vel.size());

	//ROS_ERROR_STREAM("Min: " << min_v << "   Max: " << max_v << "   Avg:  " << vel_avg_calc);

	// double max_dist = 2.0;
	// int min_points = 25;

	int right = (int) roundf(((width * (vel_perc_focus/2.0)) / 100.0) + (cur_x_delay * width));
	int left = (int) roundf(((width * (100 - (vel_perc_focus/2.0))) / 100.0) + (cur_x_delay * width));
	int point_counter = 0;
	int points_checked = 0;
	for(int i=0; i<_data->points.size(); ++i)
	{
		if( right > width != left > width )
		{
			if( _data->points.at(i).w < ((right > left) ? left : right) % (width+1) && _data->points.at(i).w > ((right < left) ? left : right) % (width+1))
				continue;
		}
		else
		{
			// ROS_ERROR_STREAM("Left: " << ((right < left) ? left : right) << "   Right:  " << ((right > left) ? left : right) );
			if( ! (_data->points.at(i).w < ((right < left) ? left : right) % (width+1) && _data->points.at(i).w > ((right > left) ? left : right) % (width+1)) )
				continue;
		}

		if(_data->points.at(i).radius == 0 || (! _data->points.at(i).point_in_vel_window))
		{
			continue;
		}

		//_data->points.at(i).vel -= vel_avg_calc;
		points_checked++;

		if(_data->points.at(i).vel == 0 || (_data->points.at(i).vel >= MinVel && _data->points.at(i).vel <= MaxVel))
		{
			continue;
		}

		// if( _data->points.at(i).vel < MinVel )
		// {
		// 	_data->points.at(i).r = 0;
		// 	_data->points.at(i).b = 255;
		// 	_data->points.at(i).g = 0;
		// }
		// else if( _data->points.at(i).vel > MaxVel )
		// {
		// 	_data->points.at(i).r = 255;
		// 	_data->points.at(i).b = 0;
		// 	_data->points.at(i).g = 0;
		// }

		point_counter++;

		
		/* Scale max_dist between a = 1 and b = 3 with equation:
		 * f(x) = ((b - a)*(x - min)) / (max - min) + a
		 */
		// double cur_max_dist = (max_dist * (((2) * (_data->points.at(i).radius - min_r) / (max_r - min_r)) + 1));
		double cur_max_dist = max_dist;
		bool bin_found = false;
		for(int j=0; j<vel_bins_init.size(); ++j)
		{
			//if( vel_bins_init.at(j).MinDist(_data->points.at(i)) < cur_max_dist )
			if( vel_bins_init.at(j).CheckMinDist(cur_max_dist, i) )
			{
				bin_found = true;
				vel_bins_init.at(j).push_back(i);
				break;
			}
		}

		if( ! bin_found )
		{
			/* Create new bin */
			vel_bins_init.push_back(Bin(_data));
			/* And add point */
			vel_bins_init.back().push_back(i);
		}
	}
	ROS_INFO_STREAM_THROTTLE(1, "Velocity Coloring:\tMaxVelThresh: " << MaxVel << "\tMinVelThresh: " << MinVel << "\tPointsInThreshhold: " << point_counter << "/" << points_checked);

	//ROS_ERROR_STREAM("PERCENT:  " << ((double) point_counter) / ((double) _data->points.size() * ((100.0 - vel_perc_focus)/ 100.0)) );
	// if(((double) point_counter) / ((double) _data->points.size() * ((100.0 - vel_perc_focus)/ 100.0)) > 0.4 )
	// {
	// 	ROS_WARN_STREAM("Movement Detected.  Filtering with Gournd Filter On");
	// 	n->setParam("/GroundFilter", true);
	// }

	// return;
	
	if( vel_bins_init.empty() )
		return 0;


	/* STARTS HERE */
	// /* Create New set of bins */
	// std::vector< Bin > vel_bins;
	// // ROS_ERROR_STREAM("Num Bins Before: " << vel_bins_init.size());
	// /* Add first bin */
	// vel_bins.push_back( Bin(_data) );
	// vel_bins.back().Merge( vel_bins_init.at(0) );
	// for(int i=1; i<vel_bins_init.size(); ++i)
	// {
	// 	bool merged_bins = false;
	// 	// float mdd = 100000;
	// 	for(int j=0; j<vel_bins.size(); ++j)
	// 	{
	// 		// float md = (vel_bins_init.at(i) - vel_bins.at(j));
	// 		// mdd = std::min(md, mdd);
	// 		if( vel_bins_init.at(i).CheckDistExact(max_dist, vel_bins.at(j)) )
	// 		{
	// 			vel_bins.at(j).Merge(vel_bins_init.at(i));
	// 			merged_bins = true;
	// 			break;
	// 		}
	// 	}
	// 	if( ! merged_bins )
	// 	{
	// 		// ROS_ERROR_STREAM("Int:  " << i << "   MDD: " << mdd);
	// 		vel_bins.push_back( Bin(_data) );
	// 		vel_bins.back().Merge( vel_bins_init.at(i) );
	// 	}
	// }
	/************* END ***********/

	// ROS_ERROR_STREAM("Num Bins After: " << vel_bins.size());

	for(auto bin : vel_bins_init) // Should be vel_bins
	{
		if( bin.size() <= min_points )
			continue;

		// ROS_ERROR_STREAM("NUM POINTS:  " << bin.size() << "   Avg Dist:  " << bin.GetAvgDist());
		// ROS_INFO_STREAM("START BOX SIZE:  " << bounding_box->points.size());
		for(int i=0; i<bin.size(); ++i)
		{
			_data->points.at( bin.at(i) ).r = 255;
			_data->points.at( bin.at(i) ).b = 0;
			_data->points.at( bin.at(i) ).g = 0;
		}
		bin.GetBoundingBox(bounding_box);
		// ROS_WARN_STREAM("DONE:  " << bounding_box->points.size());
	}
	return point_counter;
}


// void MergeBins(std::vector<std::vector<int>> &in_idxs; 
// 				std::vector< pcl::PointXYZ > &centroids,
// 				std::vector<std::vector<int>> &out_idxs)
// {	
// 	if(in_idxs.size() == 0)
// 		return;

// 	/* Copy First Bin */
// 	out_idxs.push_back(in_idxs.at(0));
// 	/* Search through points for connected bins */
// 	for(int in_bin = 1; in_bin < in_idxs.size(); ++in_bin)
// 	{
// 		int found_vel_bin = 0;
// 		bool bin_found = false;
// 		for(int idx = 0; idx < vel_idxs.at(v).size(); ++idx)
// 		{
// 			for(int bin=0; bin < vel_bins.size(); ++bin)
// 			{
// 				for(int bin_idx=0; bin_idx < vel_bins.at(bin).size(); bin_idx++)
// 				{
// 					if( Dist(_data->points.at(vel_idxs.at(v).at(idx)), _data->points.at(vel_bins.at(bin).at(bin_idx))) < max_dist )
// 					{
// 						found_vel_bin = bin;
// 						bin_found = true;
// 						break;
// 					}
// 				}
// 				if( bin_found )
// 					break;
// 			}
// 			if( bin_found )
// 				break;
// 		}
// 		if( bin_found )
// 		{
// 			vel_bins.at(found_vel_bin).insert(vel_bins.at(found_vel_bin).end(), vel_idxs.at(v).begin(), vel_idxs.at(v).end());
// 		}
// 		else
// 		{
// 			vel_bins.push_back(vel_idxs.at(v));
// 		}
// 	}
// }



void AqronosPointCloud::FilterVel_OLD(const double MinVel, const double MaxVel, const double vel_perc_focus, const double cur_x_delay, const int width)
{	
	// ros::Time proc = ros::Time::now();

	/* Create pointcloud for filtering moving objects */
	// pcl::PointCloud<AqronosPoint>::Ptr velocity(new pcl::PointCloud<AqronosPoint>);
	//pcl::PointCloud<AqronosPoint>::Ptr velocity_filt(new pcl::PointCloud<AqronosPoint>);

	// build the filter
    /* Set extract_removed_indicies to true */
    pcl::ConditionalRemoval<AqronosPoint> condrem(true);
    condrem.setInputCloud( _data );


	/* Get Max of velocity */
	//int max_vel = *std::max_element(vel.begin(), vel.end());
	//int max_vel = std::max(4,(int)*std::min_element(vel.begin(), vel.end()));
	//ROS_ERROR_STREAM("MinV:  " << max_vel);

	/* Scale point colors by max velocity */
	//double vel_scale = 255.0/max_vel;

	/* Only keep velocitys in middle of graph */
	int right = (int) roundf(((width * (vel_perc_focus/2.0)) / 100.0) + (cur_x_delay * width));
	int left = (int) roundf(((width * (100 - (vel_perc_focus/2.0))) / 100.0) + (cur_x_delay * width));

	/* Filter outside section of graph */
	/* Use condition or if graph filps around due to x delay */
	if( right > width != left > width )  // left or right greater than width but not both
	{
		pcl::ConditionAnd<AqronosPoint>::Ptr cond_out(new pcl::ConditionAnd<AqronosPoint> ());
		cond_out->addComparison (pcl::FieldComparison<AqronosPoint>::ConstPtr (new
      		pcl::FieldComparison<AqronosPoint>("w", pcl::ComparisonOps::LT, ((right > left) ? left : right) % (width+1))));
		cond_out->addComparison (pcl::FieldComparison<AqronosPoint>::ConstPtr (new
      		pcl::FieldComparison<AqronosPoint>("w", pcl::ComparisonOps::GT, ((right > left) ? right : left) % (width+1))));
		condrem.setCondition( cond_out );
		condrem.filter( *(new pcl::PointCloud<AqronosPoint>) );

		// ROS_ERROR_STREAM("Keep GT " << ((right > left) ? left : right) % width << "   And LT " << ((right > left) ? right : left) % width);
	}
	else
	{
		pcl::ConditionOr<AqronosPoint>::Ptr cond_out(new pcl::ConditionOr<AqronosPoint> ());
		cond_out->addComparison (pcl::FieldComparison<AqronosPoint>::ConstPtr (new
      		pcl::FieldComparison<AqronosPoint>("w", pcl::ComparisonOps::GT, ((right < left) ? left : right) % (width+1) )));
		cond_out->addComparison (pcl::FieldComparison<AqronosPoint>::ConstPtr (new
      		pcl::FieldComparison<AqronosPoint>("w", pcl::ComparisonOps::LT, ((right < left) ? right : left) % (width+1) )));
		condrem.setCondition( cond_out );
		condrem.filter( *(new pcl::PointCloud<AqronosPoint>) );
		// ROS_ERROR_STREAM("Keep GT " << ((right < left) ? left : right) << "   Or LT " << ((right < left) ? right : left));
	}

    // pcl::IndicesConstPtr ind = condrem.getRemovedIndices();

    /* Remove Points not higher/lower than max/min Vel */

    

	// /* Setup for filter 2 */
 //    pcl::ConditionalRemoval<AqronosPoint> condrem2(true);
 //    condrem2.setInputCloud( _data );
 //    condrem2.setIndices(condrem.getRemovedIndices());

 //    /* Create Condition 2 */
 //    pcl::ConditionAnd<AqronosPoint>::Ptr cond2(new pcl::ConditionAnd<AqronosPoint> ());
	// cond2->addComparison (pcl::FieldComparison<AqronosPoint>::ConstPtr (new
	// 	pcl::FieldComparison<AqronosPoint>("vel", pcl::ComparisonOps::GT, MinVel )));
	// cond2->addComparison (pcl::FieldComparison<AqronosPoint>::ConstPtr (new
	// 	pcl::FieldComparison<AqronosPoint>("vel", pcl::ComparisonOps::LT,  MaxVel )));

	// /* Add Condition, perform filter and get removed points */
	// condrem2.setCondition(cond2);
	// condrem2.filter( *(new pcl::PointCloud<AqronosPoint>) );
	// pcl::IndicesConstPtr ind_temp = condrem2.getRemovedIndices();



 //    // ROS_ERROR_STREAM("Before:  " << ind_temp->size());

 //    pcl::StatisticalOutlierRemoval<AqronosPoint> sor(true);
	// sor.setInputCloud(_data);
	// sor.setIndices(ind_temp);
	// sor.setMeanK(7);
	// sor.setStddevMulThresh(0.05);
	// sor.setNegative(true);
	// sor.filter( *(new pcl::PointCloud<AqronosPoint>) );

	// pcl::IndicesConstPtr ind = sor.getRemovedIndices();

	// ROS_ERROR_STREAM("After:  " << ind->size());

	pcl::IndicesConstPtr ind = condrem.getRemovedIndices();
    for(auto i : *ind)
    {
    	if(_data->points.at(i).vel == 0)
    	{
    		continue; // ignore
    	}
    	else if(_data->points.at(i).vel < MinVel)
		{
			_data->points.at(i).r = 0;
			_data->points.at(i).b = 255;
			_data->points.at(i).g = 0;
		}
		else if(_data->points.at(i).vel > MaxVel)
		{
			_data->points.at(i).r = 255;
			_data->points.at(i).b = 0;
			_data->points.at(i).g = 0;
		}
    }

    // ROS_ERROR_STREAM("Velocity Filter Time:  " << (ros::Time::now() - proc).toSec());
}



/* 2d Test Filtering */
void AqronosPointCloud::FilterRadius(int height, int width)
{
	cv::Mat src(height, width, CV_32FC1);
	cv::Mat src2(height, width, CV_8UC1);
	cv::Mat dst(height, width, CV_8UC1);
	//cv::Mat dst(height, width, CV_32FC1);
	
	//std::cout << "Create" << std::endl;

	for(int w=0; w<width; ++w)
	{
		for(int h=0; h<height; ++h)
		{
			src.at<float>(h,w) = (float) vel.at(w + (h*width));
		}
	}


	//std::cout << "Filt" << std::endl;
	cv::blur(src, src, cv::Size(7,7) );

	double max_r = *std::max_element(vel.begin(), vel.end());
	double min_r = *std::min_element(vel.begin(), vel.end());
	src.convertTo(src2, CV_8UC1, 255.0/(max_r-min_r), -255.0*min_r/(max_r - min_r));

	cv::Canny( src2 ,dst, 50, 50 );
	//cv::bilateralFilter(src, dst, 3, 15, 15);
	

	//std::cout << "Fil" << std::endl;
	for(int w=0; w<width; ++w)
	{
		for(int h=0; h<height; ++h)
		{
			int idx = w + (h*width);
			//_data->points.at(idx).x = ((dst.at<float>(h,w)) * cos(_data->points.at(idx).theta) * cos(_data->points.at(idx).phi));
			//_data->points.at(idx).y = ((dst.at<float>(h,w)) * cos(_data->points.at(idx).theta) * sin(_data->points.at(idx).phi));
			//_data->points.at(idx).z = 30 + ((dst.at<float>(h,w)) * sin(_data->points.at(idx).theta));
			//p.y = ((double) f->radius[i]) * cos(theta[i]) * sin(phi[i]);
			//p.z = ((double) f->radius[i]) * sin(theta[i]);
			_data->points.at(idx).z += 30;

			if(dst.at<uint8_t>(h,w) > 0)
			{
				_data->points.at(idx).r = 255;
				_data->points.at(idx).g = 255;
				_data->points.at(idx).b = 255;
			}
			//_data->points.at(idx).r = std::min(255, dst.at<uint8_t>(h,w)*1000);
		}
	}

	//PCLRadOultiers(_data, _data, 8, 0.6);
}

int AqronosPointCloud::FilterGround(double bin_size, double theta_thresh, int bin_thresh)
{
	double box_length = bin_size;
	// double max_points = box_length * box_length * 20.0;
	// double min_points = box_length * box_length * 0.2;
	double max_points = bin_thresh;
	double min_points = 3;	

	// int num_min_z_avg = 20;
	// std::vector<float> min_z_points(num_min_z_avg);

	float min_x, max_x, min_y, max_y, min_z, max_z;
	max_x = max_y = max_z = -1000000.0;
	min_x = min_y = min_z = 1000000.0;
	for( auto p : *_data )
	{
		min_x = std::min(p.x, min_x);
		max_x = std::max(p.x, max_x);
		min_y = std::min(p.y, min_y);
		max_y = std::max(p.y, max_y);
		// min_z = std::min(p.z, min_z);
		// max_z = std::max(p.z, max_z);
		// if(min_z_points.size() < num_min_z_avg || min_z_points.at())
		// {
		// 	/* Find Index */
		// 	auto it = std::lower_bound(min_z_points.begin(), min_z_points.end(), p.z); 
		// 	/* Insert into sorted vector */
  //   		min_z_points.insert(it, p.z);
		// }
	}
	

	int box_cols = ceil((max_x - min_x)/box_length);
	int box_rows = ceil((max_y - min_y)/box_length);
	std::vector < std::vector<int> > idxs;
	for(int i=0; i<(box_cols*box_rows); ++i)
	{
		idxs.push_back(std::vector<int>());
	}
	// std::cout << "box_cols: " << box_cols << " rows:  " << box_rows << std::endl;
	if(box_cols*box_rows == 0)
	{
		return 0;
	}
	int i=0;
	for( auto p : *_data )
	{
		int x_bin = floor((p.x - min_x)/box_length);
		int y_bin = floor((p.y - min_y)/box_length);
		int bin = y_bin * box_cols + x_bin;
		if(bin >= box_cols*box_rows || bin < 0)
		{
			continue;
		}
		if(p.theta > theta_thresh)
		{
			/* Disable Bin */
			if(idxs.at(bin).size() == 0)
			{
				idxs.at(bin).push_back(-1);
			}
			else
			{
				idxs.at(bin).at(0) = -1;
			}
		}
		// else if( p.z > (min_z + theta_thresh * (max_z - min_z)))
		// {
		// 	/* Disable Bin */
		// 	if(idxs.at(bin).size() == 0)
		// 	{
		// 		idxs.at(bin).push_back(-1);
		// 	}
		// 	else
		// 	{
		// 		idxs.at(bin).at(0) = -1;
		// 	}
		// }
		else
		{
			idxs.at(bin).push_back(i);
		}
		
		i++;
	}
	// std::cout << "Num bins: " << idxs.size() << std::endl;
	// pcl::PointCloud<AqronosPoint>::Ptr keep(new pcl::PointCloud<AqronosPoint>);
	int count = 0;
	for( auto v : idxs )
	{
		if(v.size() > max_points || v.size() == 0)
		{
			continue;
		}
		/* Skip if first value of bin is disabled */
		if( v.at(0) < 0 )
		{
			continue;
		}
		for( auto id : v )
		{
			count++;
			ground_vel_max = std::max(ground_vel_max, _data->points.at(id).vel);
			ground_vel_min = std::min(ground_vel_min, _data->points.at(id).vel);
			// _data->points.at(id).r = 255;
			// _data->points.at(id).g = 255;
			// _data->points.at(id).b = 0;

			// keep->points.push_back(_data->points.at(id));
		}	
	}
	// std::cout << "coutn:  " << count << std::endl;
	// std::cout << "Max:  " <<  ground_vel_max <<  "    Min:  " << ground_vel_min << std::endl;
	return count;
	// ROS_ERROR_STREAM("Count: " << count << "  Bin Size: " << box_length << " thresh:  " << max_points);
	// _data = keep;
}