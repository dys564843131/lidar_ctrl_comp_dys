#include "ros/ros.h"
#include <ros/console.h>

#include "lidar_frame/filter2d.hpp"

int main(int argc, char ** argv)
{
	ros::init(argc, argv, "filter2d");
	ros::NodeHandle n("~");

	Filter2d f2d( n );

	ros::spin();
	return 0;
}
