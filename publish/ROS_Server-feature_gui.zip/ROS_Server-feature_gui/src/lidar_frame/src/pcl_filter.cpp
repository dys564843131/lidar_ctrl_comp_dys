#include "lidar_frame/pcl_filter.hpp"

Filter_PCL::Filter_PCL(ros::NodeHandle &n) :
	ground_coeff{new pcl::ModelCoefficients},
	test_ground_coeff{new pcl::ModelCoefficients},
	server{n},
	find_ground_thread{&Filter_PCL::FindGroundPlaneThread, this}
{
	nh = &n;

	/* Initializes dynamic params */
	f = boost::bind(&Filter_PCL::CFGCallback, this, _1, _2);
	server.setCallback(f);

	/* Initialize callbacks */
	pc_sub = nh->subscribe("/lidar_frame/pointcloud_raw", 10, &Filter_PCL::Filter, this);
	pc_pub = nh->advertise<sensor_msgs::PointCloud2>("/lidar_frame/pointcloud", 10);
	bounding_box_pub = nh->advertise<sensor_msgs::PointCloud2>("/lidar_frame/pointcloud_bounding_box", 5);
	keypoint_pub = nh->advertise<sensor_msgs::PointCloud2>("/lidar_frame/pointcloud_keypoints", 5);

	/* Timed Callback for Publishing */
	if(params.cloud_fps > 0)
	{
		last_timer_callback = ros::Time::now();
		publish_timer = nh->createTimer(ros::Duration(1.0 / ((double) params.cloud_fps)), &Filter_PCL::TimerCallback, this);
	}
}

Filter_PCL::~Filter_PCL()
{
	find_ground_thread.join();
}


void Filter_PCL::CFGCallback(const lidar_frame::pcl_filterConfig &config, uint32_t level)
{
	if(config.cloud_fps != params.cloud_fps && config.cloud_fps > 0)
	{
		publish_timer = nh->createTimer(ros::Duration(1.0 / ((double) config.cloud_fps)), &Filter_PCL::TimerCallback, this);
		nh->setParam("/cloud_fps", config.cloud_fps);
	}

	/* When switching to real time, clear queue */
	if( config.RealTime != params.RealTime && config.RealTime && ! pc_queue.empty() )
	{
		ROS_INFO_STREAM("[PCL Filter]:  Switching To Real Time Processing.  Clearing Queue.");
		std::queue<std::shared_ptr<AqronosPointCloud>> empty;
		queue_mutex.lock();
   		std::swap( pc_queue, empty ); //// not be thread safe
   		queue_mutex.unlock();
	}

	params = config;
}


void Filter_PCL::TimerCallback(const ros::TimerEvent& event)
{
	//ROS_INFO_STREAM("Publishing Filtered PC");

	if( ! params.RealTime && ! pc_queue.empty() )
	{
		ROS_INFO_STREAM_THROTTLE(1, "[PCL Filter]:  Last Callback:  " << (ros::Time::now() - last_timer_callback).toSec() << "s"
			<< "\tQueue Size: " << pc_queue.size());
		if((ros::Time::now() - last_timer_callback).toSec() > 2* (1.0 / ((double) params.cloud_fps)))
		{
			ROS_ERROR_STREAM("[PCL Filter]: Late Callback, took: " << (ros::Time::now() - last_timer_callback).toSec() << "s.  Queue Size: " << pc_queue.size());
		}
		last_timer_callback = ros::Time::now();

		// ROS_INFO_STREAM_THROTTLE(5,"[PCL Filter]:  Queued & Filtered PointClouds: " << pc_queue.size());
		//ROS_INFO_STREAM("[PCL Filter]:  Queued & Filtered PointClouds: " << pc_queue.size());
		PublishNext();
	}
}

void Filter_PCL::AdjustGroundPlane(std::shared_ptr<AqronosPointCloud> &pc)
{
	double off=0.01;

	int orig_points;
	// if( ground_coeff->values.size() > 0)
	// {
	// 	orig_points = pc->GroundFilter(ground_coeff, params.GroundPlaneWidth, false);
	// 	int other_points = pc->GroundFilter(test_ground_coeff, params.GroundPlaneWidth, false);
	// 	if(other_points > orig_points)
	// 	{
	// 		ground_coeff = test_ground_coeff;
	// 	}
	// }
	// else
	// {
	// 	ground_coeff = test_ground_coeff;
	// 	orig_points = pc->GroundFilter(ground_coeff, params.GroundPlaneWidth, false);
	// }

	ground_coeff = test_ground_coeff;
	return;
	orig_points = pc->GroundFilter(ground_coeff, params.GroundPlaneWidth, false);
	
	int base_points;
	for(int i=0; i<ground_coeff->values.size(); ++i)
	// for(int i=2; i<3; ++i)
	{
		// if(i == 2)
		// {
		// 	continue;
		// }
		base_points = pc->GroundFilter(ground_coeff, params.GroundPlaneWidth, false);
		int below_points = base_points;
		int below_count = 0;
		do
		{
			base_points = below_points;
			ground_coeff->values.at(i) -= off;
			below_points = pc->GroundFilter(ground_coeff, params.GroundPlaneWidth, false);
			below_count++;
		} while(base_points != 0 && below_points != 0 && below_points >= base_points);
		// } while(below_count < 15 );
		ground_coeff->values.at(i) += off;
		below_count--;

		int above_points = base_points;
		int above_count = 0;
		do
		{
			base_points = above_points;
			ground_coeff->values.at(i) += off;
			above_points = pc->GroundFilter(ground_coeff, params.GroundPlaneWidth, false);
			above_count++;
		} while(base_points != 0 && above_points != 0 && above_points >= base_points);
		// } while(above_count < 15 );

		ground_coeff->values.at(i) -= off;
		above_count--;

		// ROS_INFO_STREAM("Adjust " << above_count + below_count << " param: " << i << " by: " << above_count*off - below_count*off << "  to: " << ground_coeff->values.at(i));
	}
	// ROS_WARN_STREAM("Param Size: " << ground_coeff->values.size() << "  Before Points: " << orig_points << "   After Points: "  << base_points);
}

void Filter_PCL::PublishNext()
{
	if( ! pc_queue.empty() )
	{
		ROS_INFO_STREAM_ONCE("[PCL Filter]:  Transmitting Filtered Point Clouds...");
		queue_mutex.lock();

		ApplyFilter(pc_queue.front());

		pc_queue.front()->BuildMsg("world");
		pc_pub.publish(pc_queue.front()->msg);
		bounding_box_pub.publish(pc_queue.front()->box_msg);
		keypoint_pub.publish(pc_queue.front()->keypoint_msg);

		/* Check new Ground Plane */
		if( ground_frame_mutex.try_lock() )
		{
			ground_frame = pc_queue.front();
			ground_frame_mutex.unlock();
		}

		pc_queue.pop();
		queue_mutex.unlock();
	}
}

void Filter_PCL::Filter(const sensor_msgs::PointCloud2::ConstPtr& pc_in)
{
	// ROS_INFO_STREAM_ONCE("[PCL Filter]:  Recieved Pre-Filtered PointClouds...");
	pcl::PointCloud<AqronosPoint>::Ptr pc_temp(new pcl::PointCloud<AqronosPoint>);
	fromROSMsg(*pc_in, *pc_temp);

	width = pc_temp->width;
	height = pc_temp->height;

	pc_temp->height = 1;
	pc_temp->width = pc_temp->points.size();

	std::shared_ptr<AqronosPointCloud> pc(new AqronosPointCloud(nh, pc_temp));
	pc->header = pc_in->header;

	pc->interp_height = height;
	pc->interp_width = width;
	
	pc_queue.push(pc);
	//ROS_ERROR_STREAM("HEIGHT: " << pc->interp_height<< " Widht: " << pc->interp_width);
	// double x_delay = ( (double) pc_in->data.at( pc_in->data.size() - 2 )) / 255.0;
	// double y_delay = ( (double) pc_in->data.at( pc_in->data.size() - 1 )) / 255.0;
	// std::cout << "X delay:  " << x_delay << std::endl;
	// std::cout << "Y delay:  " << y_delay << std::endl;

	/* Callback after every recieved pointcloud */
	if(params.cloud_fps == 0 || params.RealTime)
	{
		PublishNext();
	}
}

void Filter_PCL::ApplyFilter(std::shared_ptr<AqronosPointCloud> &pc)
{
	ros::Time filt_timer = ros::Time::now();

	if( params.Interpolate && pc->interp_height > 1 )
	{

		pc->Interpolate(pc->interp_height, pc->interp_width, params.InterpolateThresh);
	}

	// ROS_INFO_STREAM("Apply Filter");
	pc->RemoveNaN();

	if( params.UsePCLRadOutliers )
	{
		ros::Time timer = ros::Time::now();
		int before = pc->size();
		pc->PCLRadOultiers(pc->_data, pc->_data,
							params.PCLNeighborsInRadius, params.PCLRadiusSearch);
		ROS_INFO_STREAM_THROTTLE(2, "[PCL Filter]: Radius Outlier Points Removed: "
									 << before - pc->size() << ".  Took: " 
									 << (ros::Time::now() - timer).toSec()
									 << "s" );
	}

	if( params.UsePCLStatOutlier )
	{
		ros::Time timer = ros::Time::now();
		int before = pc->size();
		pc->PCLStatOultiers(pc->_data, pc->_data,
							params.PCLMeanK, params.PCLStddevThresh);
		ROS_INFO_STREAM_THROTTLE(2, "[PCL Filter]: Statistical Outlier Points Removed: "
									 << before - pc->size() << ".  Took: " 
									 << (ros::Time::now() - timer).toSec()
									 << "s" );
	}

	/* Color marked velocity points */
	/* If FilterVel is false no points with be marked or colored */
	//pc->ColorVel(0.25, 150);
	// ROS_INFO_STREAM("Done");
	//pc->FilterVel(VelBinDist, VelBinMinPoints, WindowPerc, x_delay, frame_cols);


	if(params.GroundFilter && test_ground_coeff->values.size() > 0)
	{
		AdjustGroundPlane(pc);
		pc->GroundFilter(ground_coeff, params.GroundPlaneWidth, true);
	}

	if(params.FilterVelMinMax)
	{
		pc->FilterVel(0.25, 100, params.MinVel, params.MaxVel, 0, 0, width);
	}
	else
	{
		pc->ColorVel(0.25, 150);
	}

	if(params.VelocityColoring)
	{
		pc->VelColor();
	}
	

	ROS_INFO_STREAM_THROTTLE(2,"[PCL Filter]:  Filter Processing Time: " << (ros::Time::now() - filt_timer).toSec());
}



void Filter_PCL::FindGroundPlaneThread()
{
	while( ros::ok() )
	{
		if( params.GroundFilter && ground_frame != NULL )
		{
			ground_frame_mutex.lock();
			ros::Time t = ros::Time::now();
			// std::cout << "Points Before: " << ground_frame->_data->points.size() << std::endl;
			ground_frame->RemoveNaN();
			// std::cout << "Points no NaN: " << ground_frame->_data->points.size() << std::endl;
			// double max_theta = RADIAN(std::max(y_angle0, y_angle1));
			// double min_theta = RADIAN(std::min(y_angle0, y_angle1));
			// double ang2 = min_theta + ((max_theta - min_theta) * (GroundFilterAngPerc / 100.0));
			// ROS_WARN_STREAM("y_ang0: " << y_angle0 << "  y_ang1: " << y_angle1 << "  max_theta:  " << max_theta << "   min_theta:  "  << min_theta <<   "  AngPerc: " << GroundFilterAngPerc << "   ang2:  " << ang2);

			// ground_frame->FilterTheta(ang2 + RADIAN(y_offset));
			// std::cout << "Points Filte Theta: " << ground_frame->_data->points.size() << std::endl;
			pcl::ModelCoefficients::Ptr coeff(new pcl::ModelCoefficients);
			int count = ground_frame->GetGroundCoeff(coeff);
			if(count > 0 && coeff->values.size() > 0)
			{
				// std::cout << (ros::Time::now() - t).toSec() << "s" << std::endl
				// 	<< "New Ground Coef: " << coeff->values.at(0) << std::endl
				// 	<< coeff->values.at(1) << std::endl
				// 	<< coeff->values.at(2) << std::endl
				// 	<< coeff->values.at(3) << std::endl;
				test_ground_coeff = coeff;
			}
			ground_frame = NULL;
			ground_frame_mutex.unlock();
		}
		std::this_thread::sleep_for(std::chrono::microseconds(200000));
	}
}