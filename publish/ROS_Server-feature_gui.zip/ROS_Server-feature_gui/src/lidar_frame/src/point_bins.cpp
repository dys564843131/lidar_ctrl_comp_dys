#include "lidar_frame/point_bins.hpp"

Bin::Bin(pcl::PointCloud<AqronosPoint>::Ptr _data) :
 	_data(_data)
{}

void Bin::push_back(int in)
{
	//std::cout << "(" <<_data->points.at(in).x << "," << _data->points.at(in).y << "," << _data->points.at(in).z << ")" << std::endl;
	/* Remove outliers */
	if(abs(_data->points.at(in).x) > 10000 || abs(_data->points.at(in).y) > 10000 || abs(_data->points.at(in).z) > 10000)
	{
		ROS_ERROR_STREAM_THROTTLE(0.001,"[Point Bins]:  Not boxing outlier point " << "(" <<_data->points.at(in).x << "," << _data->points.at(in).y << "," << _data->points.at(in).z << ")" );
		return;
	}


	if( empty() )
	{
		/* Initialize extra data */
		min_x = max_x = centroid.x = _data->points.at(in).x;
		min_y = max_y = centroid.y = _data->points.at(in).y;
		min_z = max_z = centroid.z = _data->points.at(in).z;
	}
	else
	{
		min_x = std::min(min_x, _data->points.at(in).x);
		min_y = std::min(min_y, _data->points.at(in).y);
		min_z = std::min(min_z, _data->points.at(in).z);
		max_x = std::max(max_x, _data->points.at(in).x);
		max_y = std::max(max_y, _data->points.at(in).y);
		max_z = std::max(max_z, _data->points.at(in).z);
		/* Running average */
		centroid.x = (_data->points.at(in).x + (centroid.x * idxs.size())) / (idxs.size() + 1);
		centroid.y = (_data->points.at(in).y + (centroid.y * idxs.size())) / (idxs.size() + 1);
		centroid.z = (_data->points.at(in).z + (centroid.z * idxs.size())) / (idxs.size() + 1);
	}

	idxs.push_back(in);
}

void Bin::Merge(Bin& other)
{
	for(int i=0; i < other.size(); ++i)
	{
		this->push_back(other.at(i));
	}
}

int Bin::at(int idx)
{
	return idxs.at(idx);
}

bool Bin::empty()
{
	return idxs.size() == 0;
}

size_t Bin::size()
{
	return idxs.size();
}

float Bin::MinDist(AqronosPoint p)
{
	double min_dist = 1000000;

	for(int j=0; j< this->size(); ++j)
	{
		min_dist = std::min( min_dist, Dist(p, _data->points.at(this->at(j))) );
	}

	return min_dist;
}

/* Return minimum distance between two bin points */
float Bin::operator-(Bin& other)
{
	float min_dist = 1000000;

	/* Check dist against all points between each bin */
	for(int i=0; i < other.size(); ++i)
	{
		min_dist = std::min( MinDist(_data->points.at(other.at(i))), min_dist );
	}
	return min_dist;
}

bool Bin::CheckDistExact(const double max_dist, Bin& other)
{
	double min_dist = 1000000;

	/* Check dist against all points between each bin */
	for(int i=0; i < other.size(); ++i)
	{
		for(int j=0; j< this->size(); ++j)
		{
			if( Dist(_data->points.at(this->at(j)), _data->points.at(other.at(i))) < max_dist )
				return true;
		}
	}
	return false;
}

bool Bin::CheckMinDistExact(const double max_dist, int point_idx)
{
	for(int j=0; j< this->size(); ++j)
	{
		if( Dist(_data->points.at(point_idx), _data->points.at(this->at(j))) < max_dist )
		{
			return true;
		}
	}
	return false;
}


bool Bin::CheckDist(const double max_dist, Bin& other)
{
	// if(this->size() < 5 && other.size() < 5)
	// {
	// 	return CheckDistExact(max_dist, other);
	// }

	double dist_between_cents = Dist(this->centroid, other.centroid);
	/* Get closest corner on this bounding box to other center */
	double corn_x_this = abs(other.centroid.x - this->min_x) > abs(other.centroid.x - this->max_x) ? this->max_x : this->min_x;
	double corn_y_this = abs(other.centroid.y - this->min_y) > abs(other.centroid.y - this->max_y) ? this->max_y : this->min_y;
	double corn_z_this = abs(other.centroid.z - this->min_z) > abs(other.centroid.z - this->max_z) ? this->max_z : this->min_z;
	/* Get closest corner on other bounding box to this center */
	double corn_x_oth = abs(this->centroid.x - other.min_x) > abs(this->centroid.x - other.max_x) ? other.max_x : other.min_x;
	double corn_y_oth = abs(this->centroid.y - other.min_y) > abs(this->centroid.y - other.max_y) ? other.max_y : other.min_y;
	double corn_z_oth = abs(this->centroid.z - other.min_z) > abs(this->centroid.z - other.max_z) ? other.max_z : other.min_z;

	double dist_to_this_corner = Dist(AqronosPoint(corn_x_this, corn_y_this, corn_z_this), this->centroid);
	double dist_to_other_corner = Dist(AqronosPoint(corn_x_oth, corn_y_oth, corn_z_oth), other.centroid);

	return (dist_between_cents - dist_to_this_corner - dist_to_other_corner) < max_dist;
}

bool Bin::CheckMinDist(const double max_dist, int point_idx)
{
	// if(size() < 5)
	// {
	// 	return CheckMinDistExact(max_dist, point_idx);
	// }

	return CheckMinDist(max_dist, _data->points.at(point_idx));
}

bool Bin::CheckMinDist(const double max_dist, AqronosPoint &p)
{
	/* Easy approximation of distance to bounding box:
	 *  1).  Get the distance from the centroid to the point
	 *	2).  Subtract the distance from the centroid to the closest corner to the point
	*/
	double dist_from_point_to_cent = Dist(centroid, p);
	/* Get points for closest corner */
	double corn_x = abs(p.x - min_x) > abs(p.x - max_x) ? max_x : min_x;
	double corn_y = abs(p.y - min_y) > abs(p.y - max_y) ? max_y : min_y;
	double corn_z = abs(p.z - min_z) > abs(p.z - max_z) ? max_z : min_z;

	double dist_from_cent_to_corn = Dist(AqronosPoint(corn_x, corn_y, corn_z), centroid);

	return (dist_from_point_to_cent - dist_from_cent_to_corn) < max_dist;
}

void Bin::GetBoundingBox(pcl::PointCloud<AqronosPoint>::Ptr bounding_box)
{

	for(auto in : idxs)
	{
		min_x = std::min(min_x, _data->points.at(in).x);
		min_y = std::min(min_y, _data->points.at(in).y);
		min_z = std::min(min_z, _data->points.at(in).z);
		max_x = std::max(max_x, _data->points.at(in).x);
		max_y = std::max(max_y, _data->points.at(in).y);
		max_z = std::max(max_z, _data->points.at(in).z);
	}

	/* Length: Positive x from point */
	/* Width: Positive y from point */
	/* Height: Positive z */
	if( this->empty() )
		return ;

	double length = max_x - min_x;
	double width = max_y - min_y;
	double height = max_z - min_z;
	pcl::PointXYZ orig(min_x, min_y, min_z);

	for(double i=0.0; i < length; i+=POINTS_PER_DIST)
	{
		AqronosPoint p0(orig.x + i, orig.y, orig.z, 0, 255, 0);
		AqronosPoint p1(orig.x + i, orig.y + width, orig.z, 0, 255, 0);
		AqronosPoint p2(orig.x + i, orig.y, orig.z + height, 0, 255, 0);
		AqronosPoint p3(orig.x + i, orig.y + width, orig.z + height, 0, 255, 0);
		bounding_box->points.push_back(p0);
		bounding_box->points.push_back(p1);
		bounding_box->points.push_back(p2);
		bounding_box->points.push_back(p3);
	}
	for(double i=0.0; i < width; i+=POINTS_PER_DIST)
	{
		AqronosPoint p0(orig.x, orig.y + i, orig.z, 0, 255, 0);
		AqronosPoint p1(orig.x + length, orig.y + i, orig.z, 0, 255, 0);
		AqronosPoint p2(orig.x, orig.y + i, orig.z + height, 0, 255, 0);
		AqronosPoint p3(orig.x + length, orig.y + i, orig.z + height, 0, 255, 0);
		bounding_box->points.push_back(p0);
		bounding_box->points.push_back(p1);
		bounding_box->points.push_back(p2);
		bounding_box->points.push_back(p3);
	}
	for(double i=0.0; i < height; i+=POINTS_PER_DIST)
	{
		AqronosPoint p0(orig.x, orig.y, orig.z + i, 0, 255, 0);
		AqronosPoint p1(orig.x + length, orig.y, orig.z + i, 0, 255, 0);
		AqronosPoint p2(orig.x, orig.y + width, orig.z + i, 0, 255, 0);
		AqronosPoint p3(orig.x + length, orig.y + width, orig.z + i, 0, 255, 0);
		bounding_box->points.push_back(p0);
		bounding_box->points.push_back(p1);
		bounding_box->points.push_back(p2);
		bounding_box->points.push_back(p3);
	}

	return;
}

double Bin::GetAvgDist()
{
	if(avg_dist > 0)
		return avg_dist;
	else
		avg_dist = 0.0;

	for(auto i : idxs)
	{
		avg_dist += Dist(centroid, _data->points.at(i));
	}
	avg_dist /= idxs.size();
	return avg_dist;
}